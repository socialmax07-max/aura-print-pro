# AURA Print Pro — Production Hardware & QZ Tray Setup Guide

This operational manual outlines the exact technical procedures for connecting local Windows printing hardware (USB/LAN/Wi-Fi) to the AURA Print Pro cloud SaaS platform via the QZ Tray WebSocket bridge.

---

## 1. System Requirements & Architecture

AURA Print Pro uses a dual-engine printing architecture:
1. **Primary Engine (Silent Direct Spooling):** QZ Tray WebSocket Bridge operating on `localhost:8182` (WSS) and `localhost:8181` (WS).
2. **Resilient Fallback Engine:** Native Browser Print dialog rendering the stored high-resolution document stream directly if the hardware daemon is offline.

### Shop Counter PC Prerequisites
- **Operating System:** Windows 10 (64-bit) or Windows 11.
- **Runtime Environment:** Java Runtime Environment (JRE) 8 or higher, or Adoptium Eclipse Temurin OpenJDK 17.
- **Hardware Connection:** Direct USB 2.0/3.0 cable connection or static IP network assignment (LAN/Wi-Fi).
- **Supported Printers:**
  - **Monochrome Laser:** HP LaserJet 1020 Plus, HP LaserJet Pro MFP M126nw, Canon imageCLASS LBP2900B / MF3010, Brother HL-L2321D / DCP-L2541DW.
  - **Color InkTank / Photo:** Epson EcoTank L3150 / L3210 / L805 (6-color photo), Canon PIXMA G2010 / G3010, HP Smart Tank 580.

---

## 2. QZ Tray Installation & Configuration

### Step 1: Install QZ Tray Daemon
1. Download the verified release of **QZ Tray (v2.1 or v2.2)** from the official repository or vendor distribution:
   - Official URL: `https://qz.io/download/`
2. Run the installer as **Administrator** (`qz-tray-x.x.x.exe`).
3. During setup, ensure the following checkboxes are enabled:
   - `Automatically start QZ Tray on Windows boot`
   - `Install local SSL/TLS certificate for localhost`
4. Complete installation and verify the green QZ Tray icon appears in the Windows system tray (bottom-right taskbar).

### Step 2: SSL/TLS Certificate & Port Verification
Modern web browsers enforce HTTPS. To communicate from `https://your-domain.com` to `localhost`, QZ Tray runs an encrypted local secure WebSocket service.

1. Right-click the QZ Tray icon in the system tray and select **Site Manager**.
2. Verify that port **8182 (Secure WebSocket)** is active.
3. If using an enterprise domain with digital signing:
   - Navigate to **Advanced** > **Certificates**.
   - Import your domain's public signing certificate or allow the pre-configured self-signed local certificate for `localhost`.
4. Add your production SaaS origin to the allowed sites list:
   ```text
   [https://app.auraprint.pro](https://app.auraprint.pro)
   https://*.netlify.app
   http://localhost:5173
   