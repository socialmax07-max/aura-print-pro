# AURA Print Pro — Enterprise Security, Tenant Isolation & Fraud Prevention

This document details the security architecture, data governance principles, and fraud protection mechanisms implemented across the AURA Print Pro cloud printing ecosystem.

---

## 1. Zero-Trust Multi-Tenancy Architecture

AURA Print Pro enforces strict multi-tenant boundary isolation at the database, storage, and networking layers.

### 1.1 Tenant Isolation Model
- **Firestore Partitioning:** Every shop operates within its isolated path: `/shops/{shopId}`. Orders, settings, audit logs, and rate matrices are sub-collections strictly bounded by that shop's scope (`/shops/{shopId}/orders/{orderId}`).
- **Cross-Tenant Prevention:** An authenticated Shop Owner (`SHOP_OWNER`) or Staff Member (`SHOP_STAFF`) can only query and mutate data where `request.auth.token.shopId == shopId`. Requests with mismatched IDs are rejected by Firestore security rules prior to query execution.
- **Super Admin Exception:** Only accounts with the cryptographically signed `SUPER_ADMIN` custom claim (platform owner) possess cross-tenant oversight for platform-wide metrics and emergency lock-switch toggles.

### 1.2 Cryptographic Custom Claims (Firebase Admin SDK)
Role verification does not depend on mutable client-side database records. All roles and shop associations are encoded directly into the user's signed Firebase ID Token:
- Tokens are issued with claims: `{ role: 'SUPER_ADMIN' | 'SHOP_OWNER' | 'SHOP_STAFF' | 'CUSTOMER', shopId: string | null }`.
- Claims can only be granted by the server-side Netlify Serverless Function (`adminClaims.ts`) using the verified Google Cloud Private Key.
- Client applications inspect claims via `user.getIdTokenResult(true)`, guaranteeing zero client-side role forgery.

---

## 2. Storage Hardening & Document Privacy

Customer documents handled in CSC shops and cyber cafes contain sensitive personal identifiable information (PII) such as government identity cards, educational certificates, and financial statements.

### 2.1 Storage Path Isolation
Uploaded files are stored strictly under:
```text
/shops/{shopId}/orders/{orderId}/{shortRef}.{ext}
