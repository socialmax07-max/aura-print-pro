import { Handler, HandlerEvent, HandlerContext } from '@netlify/functions';
import * as admin from 'firebase-admin';

// ============================================================================
// FIREBASE ADMIN SDK SINGLETON INITIALIZATION
// ============================================================================
if (!admin.apps.length) {
  const projectId = process.env.VITE_FIREBASE_PROJECT_ID || process.env.FIREBASE_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  // Handle escaped newlines in environment variable private key strings
  const privateKey = process.env.FIREBASE_PRIVATE_KEY
    ? process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n')
    : undefined;

  if (projectId && clientEmail && privateKey) {
    admin.initializeApp({
      credential: admin.credential.cert({
        projectId,
        clientEmail,
        privateKey,
      }),
    });
  } else {
    // Fallback to application default credentials if explicitly provided in environment
    admin.initializeApp();
  }
}

// Allowed Roles Schema
type UserRole = 'SUPER_ADMIN' | 'SHOP_OWNER' | 'SHOP_STAFF' | 'CUSTOMER';

interface ClaimsRequestBody {
  targetUid?: string;
  targetEmail?: string;
  role: UserRole;
  shopId?: string; // Required when role is SHOP_OWNER or SHOP_STAFF
}

const headers = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-admin-bootstrap-key',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

export const handler: Handler = async (event: HandlerEvent, _context: HandlerContext) => {
  // 1. Handle CORS Preflight Requests
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers,
      body: '',
    };
  }

  // Only allow POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method Not Allowed. Use POST.' }),
    };
  }

  try {
    // ------------------------------------------------------------------------
    // 2. AUTHENTICATION & AUTHORIZATION VERIFICATION
    // ------------------------------------------------------------------------
    const authHeader = event.headers.authorization || event.headers.Authorization;
    const bootstrapKeyHeader = event.headers['x-admin-bootstrap-key'];
    const serverBootstrapSecret = process.env.ADMIN_BOOTSTRAP_SECRET;

    let isAuthorized = false;
    let authorizedBy = '';

    // Route A: Master Bootstrap Secret Validation (For Initial Super Admin Setup)
    if (
      serverBootstrapSecret &&
      bootstrapKeyHeader &&
      bootstrapKeyHeader === serverBootstrapSecret
    ) {
      isAuthorized = true;
      authorizedBy = 'BOOTSTRAP_KEY';
    } 
    // Route B: Verified Super Admin Bearer Token
    else if (authHeader && authHeader.startsWith('Bearer ')) {
      const idToken = authHeader.split('Bearer ')[1].trim();
      try {
        const decodedToken = await admin.auth().verifyIdToken(idToken);
        if (decodedToken.role === 'SUPER_ADMIN') {
          isAuthorized = true;
          authorizedBy = `SUPER_ADMIN:${decodedToken.uid}`;
        }
      } catch (tokenErr) {
        return {
          statusCode: 401,
          headers,
          body: JSON.stringify({ error: 'Invalid or expired Firebase ID token.' }),
        };
      }
    }

    if (!isAuthorized) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ 
          error: 'Forbidden. Requires Super Admin ID Token or valid Master Bootstrap Key.' 
        }),
      };
    }

    // ------------------------------------------------------------------------
    // 3. PAYLOAD PARSING & VALIDATION
    // ------------------------------------------------------------------------
    if (!event.body) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Missing JSON request body.' }),
      };
    }

    const payload: ClaimsRequestBody = JSON.parse(event.body);
    const { targetUid, targetEmail, role, shopId } = payload;

    if (!role || !['SUPER_ADMIN', 'SHOP_OWNER', 'SHOP_STAFF', 'CUSTOMER'].includes(role)) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Invalid role specified.' }),
      };
    }

    if ((role === 'SHOP_OWNER' || role === 'SHOP_STAFF') && !shopId) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'shopId is required for SHOP_OWNER and SHOP_STAFF roles.' }),
      };
    }

    // ------------------------------------------------------------------------
    // 4. LOCATE TARGET USER
    // ------------------------------------------------------------------------
    let resolvedUid = targetUid;

    if (!resolvedUid && targetEmail) {
      try {
        const userRecord = await admin.auth().getUserByEmail(targetEmail.trim().toLowerCase());
        resolvedUid = userRecord.uid;
      } catch (err: any) {
        return {
          statusCode: 404,
          headers,
          body: JSON.stringify({ error: `User with email "${targetEmail}" was not found in Firebase Auth.` }),
        };
      }
    }

    if (!resolvedUid) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Either targetUid or targetEmail must be provided.' }),
      };
    }

    // ------------------------------------------------------------------------
    // 5. ATOMIC ASSIGNMENT OF CUSTOM CLAIMS
    // ------------------------------------------------------------------------
    const customClaims: Record<string, any> = {
      role,
    };

    if (role === 'SHOP_OWNER' || role === 'SHOP_STAFF') {
      customClaims.shopId = shopId;
    } else {
      customClaims.shopId = null;
    }

    await admin.auth().setCustomUserClaims(resolvedUid, customClaims);

    // Audit log
    console.log(
      `[AURA Audit] Claims updated for UID: ${resolvedUid} | Role: ${role} | Shop: ${shopId || 'NONE'} | By: ${authorizedBy}`
    );

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: `Successfully set custom claims for user ${resolvedUid}`,
        claims: customClaims,
      }),
    };
  } catch (error: any) {
    console.error('[AURA Error] Netlify Function claims assignment error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Internal server error while setting user claims.',
        details: error?.message || 'Unknown error',
      }),
    };
  }
};
