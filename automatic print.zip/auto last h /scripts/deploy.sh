#!/usr/bin/env bash

# ==============================================================================
# AURA Print Pro — Production Deployment & Automated Validation Script
# ==============================================================================
# Strict Bash Mode: Terminate on error, unbound variables, or pipe failures
set -euo pipefail

# Visual Formatting Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

log_step() {
  echo -e "\n${BLUE}${BOLD}==>${NC} ${CYAN}${1}${NC}"
}

log_success() {
  echo -e "${GREEN}${BOLD}✔${NC} ${GREEN}${1}${NC}"
}

log_warn() {
  echo -e "${YELLOW}${BOLD}⚠${NC} ${YELLOW}${1}${NC}"
}

log_error() {
  echo -e "${RED}${BOLD}✖ ERROR:${NC} ${RED}${1}${NC}" >&2
}

# ------------------------------------------------------------------------------
# STEP 1: PRE-FLIGHT ENVIRONMENT & TOOLING INSPECTION
# ------------------------------------------------------------------------------
log_step "Checking local runtime environment and deployment CLI tools..."

command -v node >/dev/null 2>&1 || { log_error "Node.js is not installed."; exit 1; }
command -v npm >/dev/null 2>&1 || { log_error "npm is not installed."; exit 1; }

NODE_VERSION=$(node -v)
NPM_VERSION=$(npm -v)
echo -e "   Node Version: ${BOLD}${NODE_VERSION}${NC}"
echo -e "   npm Version:  ${BOLD}${NPM_VERSION}${NC}"

# Check for production environment variables file
if [ ! -f ".env" ] && [ ! -f ".env.production" ]; then
  log_warn "No .env or .env.production file detected in root. Ensure environment variables are configured in Netlify dashboard."
else
  log_success "Environment configuration found."
fi

# ------------------------------------------------------------------------------
# STEP 2: DEPENDENCY SYNCHRONIZATION
# ------------------------------------------------------------------------------
log_step "Verifying and synchronizing project dependencies..."

if [ -f "package-lock.json" ]; then
  npm ci --silent
else
  npm install --silent
fi
log_success "Node modules synchronized cleanly."

# ------------------------------------------------------------------------------
# STEP 3: STRICT TYPESCRIPT STATIC ANALYSIS
# ------------------------------------------------------------------------------
log_step "Running strict TypeScript compilation checks (tsc --noEmit)..."

npx tsc --noEmit
log_success "Zero TypeScript type errors detected across codebase."

# ------------------------------------------------------------------------------
# STEP 4: RUNNING AUTOMATED UNIT TESTS
# ------------------------------------------------------------------------------
log_step "Executing test suite for Pricing Engine, Zod Schemas & State Transitions..."

if npm test -- --run; then
  log_success "All unit tests passed with 100% mathematical pricing parity."
else
  log_error "Unit tests failed. Aborting deployment to prevent production regression."
  exit 1
fi

# ------------------------------------------------------------------------------
# STEP 5: PRODUCTION BUNDLE COMPILATION (Vite)
# ------------------------------------------------------------------------------
log_step "Compiling minified production assets with Vite..."

npm run build

if [ ! -d "dist" ] || [ ! -f "dist/index.html" ]; then
  log_error "Build output missing. 'dist/index.html' was not generated."
  exit 1
fi
log_success "Production bundles generated successfully in ./dist"

# ------------------------------------------------------------------------------
# STEP 6: DEPLOY FIREBASE SECURITY RULES & INDEXES
# ------------------------------------------------------------------------------
log_step "Deploying Firebase Firestore Rules, Indexes & Storage Security Policies..."

if command -v firebase >/dev/null 2>&1; then
  # Deploy tenant isolation rules and custom storage constraints
  firebase deploy --only firestore:rules,firestore:indexes,storage
  log_success "Multi-tenant Firestore & Storage security rules deployed."
else
  log_warn "Firebase CLI ('firebase') not found globally. Skipping direct rules push."
  log_warn "Remember to deploy 'firestore.rules' and 'storage.rules' via Firebase Console."
fi

# ------------------------------------------------------------------------------
# STEP 7: NETLIFY PRODUCTION DEPLOYMENT
# ------------------------------------------------------------------------------
log_step "Deploying static assets and serverless functions to Netlify..."

if command -v netlify >/dev/null 2>&1; then
  netlify deploy --prod --dir=dist --functions=netlify/functions
  log_success "Platform successfully published to Netlify Production CDN!"
else
  log_warn "Netlify CLI ('netlify') not found globally."
  log_warn "Commit and push your changes to GitHub to trigger Netlify auto-deployment:"
  echo -e "   ${BOLD}git add . && git commit -m 'Release: AURA Print Pro production build' && git push origin main${NC}"
fi

# ------------------------------------------------------------------------------
# DEPLOYMENT VERIFICATION COMPLETE
# ------------------------------------------------------------------------------
echo -e "\n${GREEN}${BOLD}==============================================================================${NC}"
echo -e "${GREEN}${BOLD}✔ AURA PRINT PRO PRODUCTION DEPLOYMENT PIPELINE COMPLETE${NC}"
echo -e "${GREEN}${BOLD}==============================================================================${NC}\n"
echo -e "Operational Endpoints:"
echo -e "  • Customer Kiosk Gateway:    ${CYAN}https://your-domain.com/s/<shop-id>${NC}"
echo -e "  • Shopkeeper Dashboard:      ${CYAN}https://your-domain.com/s/<shop-id>/dashboard${NC}"
echo -e "  • Root Super Admin Portal:   ${CYAN}https://your-domain.com/admin${NC}\n"
