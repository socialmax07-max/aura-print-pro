import { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'sonner';

// ============================================================================
// LAZY LOADING (Code Splitting for Performance)
// Hum har experience ko alag chunk mein load karenge taaki Customer Kiosk 
// fast load ho aur usme Admin/Dashboard ka heavy code shamil na ho.
// ============================================================================

// 1. Core / Public
const LandingPage = lazy(() => import('./pages/marketing/LandingPage'));
const AuthPage = lazy(() => import('./pages/auth/AuthPage'));

// 2. Customer Kiosk (Public but Tenant-Specific)
const KioskApp = lazy(() => import('./pages/kiosk/KioskApp'));

// 3. Shopkeeper Dashboard (Protected)
const ShopDashboardApp = lazy(() => import('./pages/dashboard/ShopDashboardApp'));

// 4. Super Admin Portal (Highly Protected - For Sabir Ansari)
const SuperAdminApp = lazy(() => import('./pages/admin/SuperAdminApp'));

// ============================================================================
// GLOBAL CONFIGURATION
// ============================================================================

// React Query for caching, automatic retries, and state management
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false, // Prevents unnecessary reads to Firestore to save costs
      staleTime: 5 * 60 * 1000, // 5 minutes cache
    },
  },
});

// Full-screen loading fallback during chunk loading
const PageLoader = () => (
  <div className="min-h-screen flex items-center justify-center bg-surface-muted">
    <div className="flex flex-col items-center gap-4">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-600"></div>
      <p className="text-brand-900 font-medium font-sans animate-pulse">Loading AURA Print Pro...</p>
    </div>
  </div>
);

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        {/* Global Toast Notifications (Success/Error messages) */}
        <Toaster position="top-center" richColors closeButton />

        <Suspense fallback={<PageLoader />}>
          <Routes>
            {/* Public SaaS Routes */}
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<AuthPage />} />

            {/* Experience 1: Customer Kiosk (e.g., auraprint.pro/s/cyber-cafe-1) */}
            <Route path="/s/:shopId/*" element={<KioskApp />} />

            {/* Experience 2: Shopkeeper Dashboard (Protected) */}
            <Route path="/s/:shopId/dashboard/*" element={<ShopDashboardApp />} />

            {/* Experience 3: Super Admin Portal (Protected) */}
            <Route path="/admin/*" element={<SuperAdminApp />} />

            {/* Catch-all: Redirect unknown routes safely to landing page */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Suspense>
      </BrowserRouter>
    </QueryClientProvider>
  );
}
