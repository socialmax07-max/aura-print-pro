import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { 
  Camera, 
  RotateCw, 
  ZoomIn, 
  Sliders, 
  Grid, 
  ArrowRight, 
  RefreshCcw, 
  Download, 
  Upload, 
  CheckCircle2, 
  AlertCircle 
} from 'lucide-react';
import { toast } from 'sonner';
import { formatINR } from '@/lib/utils';
import { ShopDetails } from '@/pages/kiosk/KioskApp';

interface PassportStudioProps {
  shop: ShopDetails;
  onComplete: (file: File, photoCount: number, totalPrice: number) => void;
  onCancel?: () => void;
}

type PresetType = '35x45' | '2x2' | 'custom';

// A4 sheet physical dimensions in millimeters
const A4_WIDTH_MM = 210;
const A4_HEIGHT_MM = 297;

// Canvas render resolution: 11.81 pixels per mm (~300 DPI for print lab quality)
const PIXELS_PER_MM = 11.811;

export default function PassportStudio({ shop, onComplete, onCancel }: PassportStudioProps) {
  // Input image state
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [imageFileName, setImageFileName] = useState<string>('photo.jpg');

  // Dimension presets
  const [preset, setPreset] = useState<PresetType>('35x45');
  const [photoWidthMm, setPhotoWidthMm] = useState<number>(35);
  const [photoHeightMm, setPhotoHeightMm] = useState<number>(45);

  // Sheet layout settings
  const [marginMm, setMarginMm] = useState<number>(10);
  const [spacingMm, setSpacingMm] = useState<number>(5);
  const [selectedPhotoCount, setSelectedPhotoCount] = useState<number>(8);

  // Image manipulation controls
  const [zoom, setZoom] = useState<number>(1);
  const [rotation, setRotation] = useState<number>(0); // In degrees: 0, 90, 180, 270
  const [panX, setPanX] = useState<number>(0); // Percentage -50 to 50
  const [panY, setPanY] = useState<number>(0);

  // References
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageElementRef = useRef<HTMLImageElement | null>(null);
  const sheetCanvasRef = useRef<HTMLCanvasElement>(null);

  // Pricing configuration for photo printing
  // Cyber cafes usually charge ₹30 to ₹50 per 8-photo set or A4 glossy sheet
  const passportSheetRate = useMemo(() => {
    // If shopkeeper configured color rate, use 3x color rate or default ₹40
    return Math.max((shop.rates.colorSingle || 10) * 3, 30);
  }, [shop.rates.colorSingle]);

  // Handle Preset Switching
  const applyPreset = (type: PresetType) => {
    setPreset(type);
    if (type === '35x45') {
      setPhotoWidthMm(35);
      setPhotoHeightMm(45);
    } else if (type === '2x2') {
      setPhotoWidthMm(50.8);
      setPhotoHeightMm(50.8);
    }
  };

  // Handle Local File Upload
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error("Please upload an image file (JPG or PNG).");
      return;
    }

    setImageFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        imageElementRef.current = img;
        setImageSrc(reader.result as string);
        // Reset transformation state
        setZoom(1);
        setRotation(0);
        setPanX(0);
        setPanY(0);
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Calculate layout geometry on A4
  const layoutCalculations = useMemo(() => {
    const usableWidth = A4_WIDTH_MM - (2 * marginMm);
    const usableHeight = A4_HEIGHT_MM - (2 * marginMm);

    const cols = Math.max(1, Math.floor((usableWidth + spacingMm) / (photoWidthMm + spacingMm)));
    const rows = Math.max(1, Math.floor((usableHeight + spacingMm) / (photoHeightMm + spacingMm)));
    const maxCapacity = cols * rows;

    return { cols, rows, maxCapacity };
  }, [photoWidthMm, photoHeightMm, marginMm, spacingMm]);

  // Adjust requested photo count if geometry changes
  useEffect(() => {
    if (selectedPhotoCount > layoutCalculations.maxCapacity) {
      setSelectedPhotoCount(layoutCalculations.maxCapacity);
    }
  }, [layoutCalculations.maxCapacity, selectedPhotoCount]);

  // -------------------------------------------------------------------------
  // RENDER A4 SHEET PREVIEW & EXPORT TO 300 DPI CANVAS
  // -------------------------------------------------------------------------
  const renderCanvas = useCallback(() => {
    const canvas = sheetCanvasRef.current;
    const img = imageElementRef.current;
    if (!canvas || !img) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas dimensions to exact A4 aspect ratio at print resolution
    const canvasWidth = Math.round(A4_WIDTH_MM * PIXELS_PER_MM);
    const canvasHeight = Math.round(A4_HEIGHT_MM * PIXELS_PER_MM);
    canvas.width = canvasWidth;
    canvas.height = canvasHeight;

    // Fill crisp white background
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);

    const photoWidthPx = photoWidthMm * PIXELS_PER_MM;
    const photoHeightPx = photoHeightMm * PIXELS_PER_MM;
    const marginPx = marginMm * PIXELS_PER_MM;
    const spacingPx = spacingMm * PIXELS_PER_MM;

    const { cols } = layoutCalculations;
    const countToDraw = Math.min(selectedPhotoCount, layoutCalculations.maxCapacity);

    // Prepare cropped single photo in offscreen canvas
    const singleCanvas = document.createElement('canvas');
    singleCanvas.width = photoWidthPx;
    singleCanvas.height = photoHeightPx;
    const sCtx = singleCanvas.getContext('2d');

    if (sCtx) {
      sCtx.fillStyle = '#FFFFFF';
      sCtx.fillRect(0, 0, photoWidthPx, photoHeightPx);
      sCtx.save();

      // Center transformations
      sCtx.translate(photoWidthPx / 2, photoHeightPx / 2);
      sCtx.rotate((rotation * Math.PI) / 180);
      sCtx.scale(zoom, zoom);

      // Pan translation
      const panOffsetX = (panX / 100) * photoWidthPx;
      const panOffsetY = (panY / 100) * photoHeightPx;
      sCtx.translate(panOffsetX, panOffsetY);

      // Draw original image maintaining aspect ratio
      const imgAspect = img.width / img.height;
      const targetAspect = photoWidthPx / photoHeightPx;
      let drawW = photoWidthPx;
      let drawH = photoHeightPx;

      if (imgAspect > targetAspect) {
        drawH = photoHeightPx;
        drawW = photoHeightPx * imgAspect;
      } else {
        drawW = photoWidthPx;
        drawH = photoWidthPx / imgAspect;
      }

      sCtx.drawImage(img, -drawW / 2, -drawH / 2, drawW, drawH);
      sCtx.restore();

      // Border and cutting guideline around individual photo
      sCtx.strokeStyle = '#CCCCCC';
      sCtx.lineWidth = 2;
      sCtx.strokeRect(0, 0, photoWidthPx, photoHeightPx);
    }

    // Grid rendering across A4 sheet
    for (let i = 0; i < countToDraw; i++) {
      const col = i % cols;
      const row = Math.floor(i / cols);

      const x = marginPx + col * (photoWidthPx + spacingPx);
      const y = marginPx + row * (photoHeightPx + spacingPx);

      ctx.drawImage(singleCanvas, x, y);

      // Corner crop mark crosshairs for manual scissors or photo cutter
      ctx.strokeStyle = '#999999';
      ctx.lineWidth = 1;
      const markLen = 8;
      // Top-Left
      ctx.beginPath();
      ctx.moveTo(x - markLen, y); ctx.lineTo(x, y);
      ctx.moveTo(x, y - markLen); ctx.lineTo(x, y);
      ctx.stroke();
    }
  }, [
    photoWidthMm, 
    photoHeightMm, 
    marginMm, 
    spacingMm, 
    layoutCalculations, 
    selectedPhotoCount, 
    zoom, 
    rotation, 
    panX, 
    panY
  ]);

  // Redraw canvas whenever adjustments or dimensions update
  useEffect(() => {
    if (imageSrc) {
      renderCanvas();
    }
  }, [imageSrc, renderCanvas]);

  // Export A4 Sheet to File and proceed to order flow
  const handleProceed = () => {
    const canvas = sheetCanvasRef.current;
    if (!canvas || !imageSrc) {
      toast.error("Please upload an image before proceeding.");
      return;
    }

    canvas.toBlob((blob) => {
      if (!blob) {
        toast.error("Failed to generate print-ready file.");
        return;
      }

      const cleanFileName = `passport_${preset}_${selectedPhotoCount}photos.jpg`;
      const readyFile = new File([blob], cleanFileName, { type: 'image/jpeg' });

      onComplete(readyFile, selectedPhotoCount, passportSheetRate);
    }, 'image/jpeg', 0.95);
  };

  return (
    <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm animate-in fade-in duration-300">
      
      {/* HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-gray-100 gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 bg-brand-50 text-brand-600 rounded-lg">
              <Camera size={22} />
            </div>
            <h2 className="text-xl font-bold text-gray-900">Passport Photo Studio</h2>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            Format passport and visa photos onto standard A4 photo paper with precise cutting marks.
          </p>
        </div>

        <div className="text-right">
          <p className="text-xs text-gray-400 font-semibold uppercase">Sheet Price</p>
          <p className="text-2xl font-black text-brand-700">{formatINR(passportSheetRate)}</p>
        </div>
      </div>

      {!imageSrc ? (
        /* UPLOAD STATE */
        <div className="py-16 flex flex-col items-center justify-center text-center">
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleImageFileChange} 
            accept="image/jpeg,image/png,image/jpg" 
            className="hidden" 
          />
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="w-24 h-24 rounded-full bg-brand-50 border-2 border-dashed border-brand-300 flex items-center justify-center text-brand-600 cursor-pointer hover:bg-brand-100 transition-colors mb-4"
          >
            <Upload size={36} />
          </div>
          <h3 className="text-lg font-bold text-gray-800 mb-1">Select Passport Photo</h3>
          <p className="text-xs text-gray-500 max-w-sm mb-6">
            Upload a clear front-facing portrait. You can zoom, rotate, crop, and position on the next screen.
          </p>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="bg-brand-600 hover:bg-brand-700 text-white font-bold text-sm px-6 py-3 rounded-xl shadow-sm transition-colors"
          >
            Choose Image from Device
          </button>
        </div>
      ) : (
        /* EDITING AND LAYOUT INTERFACE */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mt-6">
          
          {/* CONTROLS COLUMN */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Presets */}
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-2">
                Photo Specification Preset
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => applyPreset('35x45')}
                  className={`py-2 px-3 rounded-xl border-2 text-xs font-bold transition-all ${
                    preset === '35x45'
                      ? 'border-brand-600 bg-brand-50 text-brand-800'
                      : 'border-gray-200 text-gray-600 hover:border-gray-300'
                  }`}
                >
                  India 35×45 mm
                </button>
                <button
                  type="button"
                  onClick={() => applyPreset('2x2')}
                  className={`py-2 px-3 rounded-xl border-2 text-xs font-bold transition-all ${
                    preset === '2x2'
                      ? 'border-brand-600 bg-brand-50 text-brand-800'
                      : 'border-gray-200 text-gray-600 hover:border-gray-300'
                  }`}
                >
                  US / Visa 2×2 in
                </button>
                <button
                  type="button"
                  onClick={() => setPreset('custom')}
                  className={`py-2 px-3 rounded-xl border-2 text-xs font-bold transition-all ${
                    preset === 'custom'
                      ? 'border-brand-600 bg-brand-50 text-brand-800'
                      : 'border-gray-200 text-gray-600 hover:border-gray-300'
                  }`}
                >
                  Custom
                </button>
              </div>
            </div>

            {/* Custom Dimension Inputs */}
            {preset === 'custom' && (
              <div className="grid grid-cols-2 gap-3 p-3 bg-gray-50 rounded-xl border border-gray-200">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Width (mm)</label>
                  <input
                    type="number"
                    min="20"
                    max="100"
                    value={photoWidthMm}
                    onChange={(e) => setPhotoWidthMm(Number(e.target.value) || 35)}
                    className="w-full p-2 bg-white border border-gray-300 rounded-lg text-sm font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Height (mm)</label>
                  <input
                    type="number"
                    min="20"
                    max="150"
                    value={photoHeightMm}
                    onChange={(e) => setPhotoHeightMm(Number(e.target.value) || 45)}
                    className="w-full p-2 bg-white border border-gray-300 rounded-lg text-sm font-bold"
                  />
                </div>
              </div>
            )}

            {/* Positioning & Zoom Controls */}
            <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-gray-200">
                <span className="text-xs font-bold text-gray-700 uppercase tracking-wider flex items-center gap-1.5">
                  <Sliders size={14} /> Framing & Crop
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setZoom(1);
                    setRotation(0);
                    setPanX(0);
                    setPanY(0);
                  }}
                  className="text-xs text-brand-600 font-semibold hover:underline flex items-center gap-1"
                >
                  <RefreshCcw size={12} /> Reset
                </button>
              </div>

              {/* Zoom Slider */}
              <div>
                <div className="flex justify-between text-xs font-semibold text-gray-600 mb-1">
                  <span>Zoom</span>
                  <span>{zoom.toFixed(1)}x</span>
                </div>
                <input
                  type="range"
                  min="0.8"
                  max="3"
                  step="0.05"
                  value={zoom}
                  onChange={(e) => setZoom(parseFloat(e.target.value))}
                  className="w-full accent-brand-600 cursor-pointer"
                />
              </div>

              {/* Rotation */}
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-gray-600">Rotate</span>
                <button
                  type="button"
                  onClick={() => setRotation((prev) => (prev + 90) % 360)}
                  className="bg-white border border-gray-300 px-3 py-1.5 rounded-lg text-xs font-bold text-gray-700 flex items-center gap-1 hover:bg-gray-100"
                >
                  <RotateCw size={13} /> {rotation}° Rotate
                </button>
              </div>

              {/* Pan Horizontal / Vertical */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-xs text-gray-500 mb-1">Pan X: {panX}%</label>
                  <input
                    type="range"
                    min="-40"
                    max="40"
                    value={panX}
                    onChange={(e) => setPanX(parseInt(e.target.value))}
                    className="w-full accent-brand-600 cursor-pointer"
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-500 mb-1">Pan Y: {panY}%</label>
                  <input
                    type="range"
                    min="-40"
                    max="40"
                    value={panY}
                    onChange={(e) => setPanY(parseInt(e.target.value))}
                    className="w-full accent-brand-600 cursor-pointer"
                  />
                </div>
              </div>
            </div>

            {/* Layout Copies Count */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-bold text-gray-700 uppercase tracking-wider">
                  Number of Photos on A4
                </label>
                <span className="text-xs font-bold text-brand-700">
                  Max: {layoutCalculations.maxCapacity} photos
                </span>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {[4, 8, 12, layoutCalculations.maxCapacity].map((count) => {
                  const actualCount = Math.min(count, layoutCalculations.maxCapacity);
                  return (
                    <button
                      key={count}
                      type="button"
                      onClick={() => setSelectedPhotoCount(actualCount)}
                      className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                        selectedPhotoCount === actualCount
                          ? 'border-brand-600 bg-brand-50 text-brand-800'
                          : 'border-gray-200 text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      {count === layoutCalculations.maxCapacity ? `All (${actualCount})` : `${actualCount} Pcs`}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3 pt-4">
              {onCancel && (
                <button
                  type="button"
                  onClick={onCancel}
                  className="flex-1 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 font-bold text-sm py-3 rounded-xl transition-colors"
                >
                  Cancel
                </button>
              )}
              <button
                type="button"
                onClick={handleProceed}
                className="flex-1 bg-brand-600 hover:bg-brand-700 text-white font-bold text-sm py-3 rounded-xl flex items-center justify-center gap-2 shadow-md transition-colors"
              >
                Send to Print <ArrowRight size={16} />
              </button>
            </div>

          </div>

          {/* PREVIEW CANVAS COLUMN */}
          <div className="lg:col-span-7 flex flex-col items-center">
            <div className="w-full bg-gray-100 rounded-2xl p-4 border border-gray-200 flex flex-col items-center">
              <div className="flex items-center justify-between w-full mb-3 px-2">
                <span className="text-xs font-bold text-gray-600 flex items-center gap-1.5">
                  <Grid size={14} /> A4 Sheet Live Preview (210×297 mm)
                </span>
                <span className="text-xs text-gray-500">
                  {selectedPhotoCount} photos • {layoutCalculations.cols} cols × {layoutCalculations.rows} rows
                </span>
              </div>

              {/* Scaled Responsive Sheet Canvas Container */}
              <div className="w-full max-w-[380px] bg-white shadow-card rounded-md overflow-hidden border border-gray-300">
                <canvas
                  ref={sheetCanvasRef}
                  className="w-full h-auto block"
                  style={{ aspectRatio: `${A4_WIDTH_MM} / ${A4_HEIGHT_MM}` }}
                />
              </div>

              <p className="text-[11px] text-gray-400 mt-3 text-center">
                High-resolution 300 DPI output with razor cutting corner guidelines.
              </p>
            </div>
          </div>

        </div>
      )}

    </div>
  );
}