import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { 
  User, 
  onAuthStateChanged, 
  signOut,
  signInAnonymously
} from 'firebase/auth';
import { auth } from '@/lib/firebase/config';

// Define the exact roles mapping to our SaaS architecture
export type UserRole = 'CUSTOMER' | 'SHOP_OWNER' | 'SHOP_STAFF' | 'SUPER_ADMIN' | null;

interface AuthContextType {
  currentUser: User | null;
  role: UserRole;
  shopId: string | null; // Null for customers/super-admin, populated for shopkeepers
  isLoading: boolean;
  logout: () => Promise<void>;
  authenticateAsCustomer: () => Promise<User | null>;
}

const AuthContext = createContext<AuthContextType>({
  currentUser: null,
  role: null,
  shopId: null,
  isLoading: true,
  logout: async () => {},
  authenticateAsCustomer: async () => null,
});

export const useAuth = () => useContext(AuthContext);

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [role, setRole] = useState<UserRole>(null);
  const [shopId, setShopId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Listen to Firebase Auth state changes
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setCurrentUser(user);
        
        try {
          // Fetch custom claims securely set by the backend Admin SDK.
          // This prevents client-side role manipulation.
          const tokenResult = await user.getIdTokenResult(true);
          const claims = tokenResult.claims;

          if (claims.role === 'SUPER_ADMIN') {
            setRole('SUPER_ADMIN');
            setShopId(null);
          } else if (claims.role === 'SHOP_OWNER') {
            setRole('SHOP_OWNER');
            // Backend should attach the associated shopId to the claim
            setShopId((claims.shopId as string) || null);
          } else if (claims.role === 'SHOP_STAFF') {
            setRole('SHOP_STAFF');
            setShopId((claims.shopId as string) || null);
          } else {
            // If logged in but no specific claim, treat as an anonymous customer
            setRole('CUSTOMER');
            setShopId(null);
          }
        } catch (error) {
          console.error("AURA Print Pro - Failed to fetch user roles:", error);
          setRole('CUSTOMER'); // Fallback to lowest privilege
        }
      } else {
        // User is logged out
        setCurrentUser(null);
        setRole(null);
        setShopId(null);
      }
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Secure logout function
  const logout = async () => {
    setIsLoading(true);
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Logout failed:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // Customers in the Kiosk don't need a full email/password account initially.
  // We use Firebase Anonymous Auth to track their specific uploads and orders securely.
  const authenticateAsCustomer = async () => {
    try {
      if (!auth.currentUser) {
        const credential = await signInAnonymously(auth);
        return credential.user;
      }
      return auth.currentUser;
    } catch (error) {
      console.error("Customer authentication failed:", error);
      return null;
    }
  };

  const value = {
    currentUser,
    role,
    shopId,
    isLoading,
    logout,
    authenticateAsCustomer
  };

  return (
    <AuthContext.Provider value={value}>
      {!isLoading ? children : (
        // Full screen secure loader while verifying roles to prevent UI flashing
        <div className="min-h-screen flex flex-col items-center justify-center bg-surface-muted">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-brand-600 mb-4"></div>
          <p className="text-brand-900 font-medium">Verifying Secure Session...</p>
        </div>
      )}
    </AuthContext.Provider>
  );
}
