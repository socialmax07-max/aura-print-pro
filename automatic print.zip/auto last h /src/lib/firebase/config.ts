import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

// Aapki real Firebase Keys yahan direct set ho gayi hain
const firebaseConfig = {
  apiKey: "AIzaSyD9ncLkKqqwGYOsk86d6CTtj8W2Kpw8eTI",
  authDomain: "aura-print-pro.firebaseapp.com",
  projectId: "aura-print-pro",
  storageBucket: "aura-print-pro.firebasestorage.app",
  messagingSenderId: "108389437934",
  appId: "1:108389437934:web:4c24fe140794e594bdfeff"
};

// Singleton initialization taaki multiple re-renders par app crash na ho
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

export default app;
