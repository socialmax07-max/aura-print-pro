import { describe, it, expect } from 'vitest';
import { calculatePrintPrice } from './pricingEngine';

describe('AURA Print Pro - Core Pricing Engine', () => {

  describe('Mandatory Business Logic Tests (Provided by Founder)', () => {
    
    it('3 B&W pages, 1 copy, single-sided = ₹6', () => {
      const result = calculatePrintPrice({ selectedPages: 3, copies: 1, isColor: false, isDuplex: false });
      expect(result.totalAmount).toBe(6);
      expect(result.sheetsUsed).toBe(3);
    });

    it('3 B&W pages, 1 copy, duplex = ₹6', () => {
      const result = calculatePrintPrice({ selectedPages: 3, copies: 1, isColor: false, isDuplex: true });
      expect(result.totalAmount).toBe(6);
      // Math.ceil(3/2) * 1 = 2 physical sheets
      expect(result.sheetsUsed).toBe(2);
    });

    it('3 B&W pages, 2 copies, duplex = ₹12', () => {
      const result = calculatePrintPrice({ selectedPages: 3, copies: 2, isColor: false, isDuplex: true });
      expect(result.totalAmount).toBe(12);
      // Math.ceil(3/2) * 2 = 2 * 2 = 4 physical sheets
      expect(result.sheetsUsed).toBe(4);
    });

    it('10 B&W pages, 2 copies, single-sided = ₹40', () => {
      const result = calculatePrintPrice({ selectedPages: 10, copies: 2, isColor: false, isDuplex: false });
      expect(result.totalAmount).toBe(40);
      // 10 * 2 = 20 physical sheets
      expect(result.sheetsUsed).toBe(20);
    });

    it('3 colour pages, 1 copy, single-sided = ₹30', () => {
      const result = calculatePrintPrice({ selectedPages: 3, copies: 1, isColor: true, isDuplex: false });
      expect(result.totalAmount).toBe(30);
      expect(result.sheetsUsed).toBe(3);
    });

    it('3 colour pages, 1 copy, duplex = ₹32', () => {
      const result = calculatePrintPrice({ selectedPages: 3, copies: 1, isColor: true, isDuplex: true });
      expect(result.totalAmount).toBe(32);
      // Math.ceil(3/2) * 1 = 2 physical sheets
      expect(result.sheetsUsed).toBe(2);
    });

    it('3 colour pages, 2 copies, duplex = ₹64', () => {
      const result = calculatePrintPrice({ selectedPages: 3, copies: 2, isColor: true, isDuplex: true });
      expect(result.totalAmount).toBe(64);
      // Math.ceil(3/2) * 2 = 2 * 2 = 4 physical sheets
      expect(result.sheetsUsed).toBe(4);
    });

    it('5 B&W pages, 3 copies, duplex = ₹27', () => {
      const result = calculatePrintPrice({ selectedPages: 5, copies: 3, isColor: false, isDuplex: true });
      expect(result.totalAmount).toBe(27);
      // Math.ceil(5/2) * 3 = 3 * 3 = 9 physical sheets
      expect(result.sheetsUsed).toBe(9);
    });
  });

  describe('Validation and Edge Cases', () => {
    
    it('Should reject zero pages', () => {
      const result = calculatePrintPrice({ selectedPages: 0, copies: 1, isColor: false, isDuplex: false });
      expect(result.totalAmount).toBe(0);
      expect(result.error).toBe("Invalid page count. Must be 1 or more.");
    });

    it('Should reject negative copies', () => {
      const result = calculatePrintPrice({ selectedPages: 5, copies: -2, isColor: false, isDuplex: false });
      expect(result.totalAmount).toBe(0);
      expect(result.error).toBe("Invalid copies count. Must be 1 or more.");
    });

    it('Should reject fractional page counts', () => {
      const result = calculatePrintPrice({ selectedPages: 2.5, copies: 1, isColor: false, isDuplex: false });
      expect(result.totalAmount).toBe(0);
      expect(result.error).toBe("Invalid page count. Must be 1 or more.");
    });
  });

});
