/**
 * AURA Print Pro - Core Pricing Engine
 * Yeh module ensure karta hai ki frontend aur backend dono exact same logic use karein
 * pricing calculate karne ke liye. Never trust client-calculated amounts!
 */

export interface PricingRates {
  bwSingle: number;
  bwDuplex: number;
  colorSingle: number;
  colorDuplex: number;
}

// Shopkeeper/Admin baad me inko database se override kar sakte hain, 
// par system ke default fallback rates yeh rahenge (as requested).
export const DEFAULT_RATES: PricingRates = {
  bwSingle: 2,    // ₹2 per printed page
  bwDuplex: 3,    // ₹3 per physical sheet
  colorSingle: 10, // ₹10 per printed page
  colorDuplex: 16, // ₹16 per physical sheet
};

export interface PrintJobConfig {
  selectedPages: number; // Kitne pages PDF se select hue (e.g., 1-5 = 5 pages)
  copies: number;        // Kitni copies chahiye
  isColor: boolean;      // True = Color, False = B&W
  isDuplex: boolean;     // True = Both sides (Duplex), False = Single-sided
}

export interface PricingResult {
  totalAmount: number;   // Final amount in INR (₹)
  sheetsUsed: number;    // Total physical paper sheets consumed
  rateApplied: number;   // Konsa rate apply hua (per page / per sheet)
  error?: string;        // Agar configuration invalid ho
}

/**
 * Calculates the exact price and sheet consumption for a print job.
 * @param job The print job parameters (pages, copies, color, duplex)
 * @param rates The rates configured for the specific shop (defaults to DEFAULT_RATES)
 * @returns PricingResult object containing total amount and sheet usage
 */
export function calculatePrintPrice(
  job: PrintJobConfig,
  rates: PricingRates = DEFAULT_RATES
): PricingResult {
  // 1. Strict Validation - Prevent zero, negative, or fractional values
  if (!Number.isInteger(job.selectedPages) || job.selectedPages <= 0) {
    return { totalAmount: 0, sheetsUsed: 0, rateApplied: 0, error: "Invalid page count. Must be 1 or more." };
  }
  if (!Number.isInteger(job.copies) || job.copies <= 0) {
    return { totalAmount: 0, sheetsUsed: 0, rateApplied: 0, error: "Invalid copies count. Must be 1 or more." };
  }

  let rateApplied = 0;
  let totalAmount = 0;
  let sheetsUsed = 0;

  // 2. Calculation Logic as per AURA Print Pro Business Rules
  if (!job.isDuplex) {
    // SINGLE-SIDED LOGIC
    // Formula: selected pages × copies × rate
    rateApplied = job.isColor ? rates.colorSingle : rates.bwSingle;
    sheetsUsed = job.selectedPages * job.copies; // 1 page = 1 physical sheet in single-sided
    totalAmount = sheetsUsed * rateApplied;
  } else {
    // DUPLEX LOGIC (Double-sided)
    // Formula: ceiling(selected pages / 2) × copies × duplex rate
    rateApplied = job.isColor ? rates.colorDuplex : rates.bwDuplex;
    const sheetsPerCopy = Math.ceil(job.selectedPages / 2);
    sheetsUsed = sheetsPerCopy * job.copies;
    totalAmount = sheetsUsed * rateApplied;
  }

  return {
    totalAmount,
    sheetsUsed,
    rateApplied,
  };
}
