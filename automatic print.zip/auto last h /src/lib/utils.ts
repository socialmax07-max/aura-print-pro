import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

/**
 * AURA Print Pro - Core Utilities
 */

/**
 * Safely merges Tailwind CSS classes and resolves conflicts.
 * Very useful for reusable UI components and conditional styling based on state (e.g., Error vs Success).
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Formats a numeric amount strictly into Indian Rupees (INR) format.
 * Prevents UI layout shifts by enforcing consistent 2 decimal places.
 * Example: 15.5 -> ₹15.50
 * 
 * @param amount The total price calculated by the pricing engine
 * @returns Formatted INR string
 */
export function formatINR(amount: number): string {
  // Defensive check against invalid inputs
  if (isNaN(amount) || amount === null) {
    return '₹0.00';
  }

  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

/**
 * Formats a given date/timestamp into a readable Indian standard format.
 * Example: "11 Oct 2026, 06:16 PM"
 * 
 * @param date Native Date object, numeric timestamp, or ISO string
 * @returns Formatted date string
 */
export function formatDate(date: Date | string | number): string {
  if (!date) return 'Unknown Date';
  
  try {
    const validDate = new Date(date);
    return new Intl.DateTimeFormat('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    }).format(validDate);
  } catch (error) {
    console.error("Date formatting error:", error);
    return 'Invalid Date';
  }
}

/**
 * Generates a short, unique reference ID for print orders.
 * Used for the Shopkeeper to quickly identify a job without typing long Firebase UUIDs.
 */
export function generateShortOrderId(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result; // Example: "X7B9Q2"
}
