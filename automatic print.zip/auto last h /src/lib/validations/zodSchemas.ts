import { z } from 'zod';

/**
 * AURA Print Pro - Zod Validation Schemas
 * Used for both Frontend Form Validation (React Hook Form) and Backend API Validation
 */

// 1. File Upload Validation
// Rejects files larger than 100MB (as per instructions)
const MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB in bytes
const ACCEPTED_FILE_TYPES = [
  'application/pdf', 
  'image/jpeg', 
  'image/jpg', 
  'image/png'
];

export const fileSchema = z.object({
  file: z.instanceof(File, { message: "A valid file is required." })
    .refine((file) => file.size <= MAX_FILE_SIZE, `File size must be less than 100MB.`)
    .refine(
      (file) => ACCEPTED_FILE_TYPES.includes(file.type),
      "Only PDF, JPG, JPEG, and PNG formats are supported."
    ),
});

// 2. Page Range String Validation (e.g., "1-5, 8, 10-12" or "all")
// Allows digits, commas, hyphens, and spaces OR the exact string "all"
const pageRangeRegex = /^all$\vert{}^[\d\s,-]+$/i;

// 3. Print Configuration Schema (Kiosk)
export const printConfigSchema = z.object({
  copies: z.number().int().min(1, "At least 1 copy is required").max(100, "Maximum 100 copies per job"),
  isColor: z.boolean(),
  isDuplex: z.boolean(),
  paperSize: z.enum(['A4', 'Letter', 'Legal']).default('A4'),
  orientation: z.enum(['portrait', 'landscape', 'auto']).default('auto'),
  pageRange: z.string().regex(pageRangeRegex, "Invalid page range format. Use 'all' or '1-5, 8, 10-12'").default('all'),
  selectedPagesCount: z.number().int().min(1, "At least 1 page must be selected for printing"),
});

// 4. Order Status Enum (Strict state machine transitions)
export const OrderStatusEnum = z.enum([
  'PENDING_PAYMENT',     // Uploaded, waiting for UPI/Cash
  'PAYMENT_VERIFYING',   // Customer clicked 'I Paid', shopkeeper needs to verify
  'AUTHORIZED',          // Shopkeeper confirmed payment received
  'REJECTED',            // Shopkeeper rejected payment / invalid file
  'QUEUED',              // Sent to QZ Tray / Print Bridge
  'PRINTING',            // Printer is actively printing
  'PRINTED',             // Successfully printed
  'PRINT_FAILED',        // Printer error / paper jam
  'CANCELLED'            // Cancelled by user before payment
]);

export type OrderStatus = z.infer<typeof OrderStatusEnum>;

// 5. Full Order Snapshot Schema (Stored in Firestore)
export const orderSnapshotSchema = z.object({
  id: z.string().optional(),
  shopId: z.string(),
  customerId: z.string(), // Anonymous session ID or authenticated user
  fileName: z.string(),
  fileStoragePath: z.string(), // Firebase storage path
  config: printConfigSchema,
  amount: z.number().positive(),
  sheetsUsed: z.number().int().positive(),
  status: OrderStatusEnum,
  paymentMethod: z.enum(['UPI', 'CASH']),
  createdAt: z.date().or(z.any()), // z.any() to accommodate Firestore Timestamp
  updatedAt: z.date().or(z.any()),
  authorizedBy: z.string().nullable().optional(), // Shopkeeper ID who confirmed payment
});

// 6. Passport Photo Config Schema
export const passportConfigSchema = z.object({
  preset: z.enum(['35x45', '2x2', 'custom']),
  widthMm: z.number().positive().max(210), // Max A4 width
  heightMm: z.number().positive().max(297), // Max A4 height
  photosPerSheet: z.number().int().positive().max(50),
  marginsMm: z.number().min(0).max(50).default(5),
  spacingMm: z.number().min(0).max(20).default(2),
});

export type PrintConfig = z.infer<typeof printConfigSchema>;
export type OrderSnapshot = z.infer<typeof orderSnapshotSchema>;
export type PassportConfig = z.infer<typeof passportConfigSchema>;
