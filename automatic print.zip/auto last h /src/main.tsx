import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

// Global styles (Tailwind CSS and custom base styles)
import './index.css';

// Ensure standard PDF.js worker is mapped for real PDF previews later
import { pdfjs } from 'react-pdf';
// Using unpkg CDN for the worker to match the installed pdfjs-dist version.
// This prevents memory issues and keeps the main bundle small.
pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;

const rootElement = document.getElementById('root');

if (!rootElement) {
  throw new Error("AURA Print Pro Error: Failed to find the root element. Check index.html");
}

ReactDOM.createRoot(rootElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
