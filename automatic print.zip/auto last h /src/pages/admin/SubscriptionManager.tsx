import React, { useState, useEffect, useMemo } from 'react';
import { 
  CreditCard, 
  TrendingUp, 
  Calendar, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  RefreshCw, 
  ShieldCheck, 
  FileText, 
  Layers,
  ArrowUpRight,
  Loader2,
  DollarSign
} from 'lucide-react';
import { collection, getDocs, doc, updateDoc, serverTimestamp, query, orderBy } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { toast } from 'sonner';
import { formatINR, formatDate } from '@/lib/utils';
import { RentalPlan, RENTAL_TIERS } from './TenantManager';

interface ShopSubscriptionRecord {
  id: string;
  name: string;
  ownerEmail: string;
  rentalTier: RentalPlan;
  isLocked: boolean;
  subscriptionExpiry: any; // Firestore Timestamp or Date string
  createdAt: any;
}

export default function SubscriptionManager() {
  const [shops, setShops] = useState<ShopSubscriptionRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'ALL' | 'ACTIVE' | 'EXPIRING_SOON' | 'EXPIRED'>('ALL');
  const [renewingShopId, setRenewingShopId] = useState<string | null>(null);
  const [renewMonths, setRenewMonths] = useState<number>(1);
  const [paymentRefNumber, setPaymentRefNumber] = useState<string>('');
  const [isSubmittingRenewal, setIsSubmittingRenewal] = useState(false);

  // Load all tenant subscription data
  const loadSubscriptions = async () => {
    setLoading(true);
    try {
      const q = query(collection(db, 'shops'), orderBy('createdAt', 'desc'));
      const snap = await getDocs(q);
      const items: ShopSubscriptionRecord[] = [];
      snap.forEach((docSnap) => {
        items.push({ id: docSnap.id, ...docSnap.data() } as ShopSubscriptionRecord);
      });
      setShops(items);
    } catch (err) {
      console.error("Failed to load subscriptions:", err);
      toast.error("Could not load tenant subscription data.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSubscriptions();
  }, []);

  // Helper to convert Firestore timestamp or ISO string to standard JS Date
  const parseDate = (val: any): Date | null => {
    if (!val) return null;
    if (val.toDate && typeof val.toDate === 'function') return val.toDate();
    const d = new Date(val);
    return isNaN(d.getTime()) ? null : d;
  };

  // --------------------------------------------------------------------------
  // FINANCIAL METRICS AGGREGATION (MRR & Expiring Pipelines)
  // --------------------------------------------------------------------------
  const metrics = useMemo(() => {
    const now = new Date();
    const sevenDaysFromNow = new Date();
    sevenDaysFromNow.setDate(now.getDate() + 7);

    let mrr = 0;
    let activeCount = 0;
    let expiringSoonCount = 0;
    let expiredCount = 0;

    shops.forEach((shop) => {
      const tierConfig = RENTAL_TIERS[shop.rentalTier] || RENTAL_TIERS.STARTER;
      const expiry = parseDate(shop.subscriptionExpiry);

      if (!shop.isLocked) {
        mrr += tierConfig.monthlyFee;
      }

      if (!expiry) {
        activeCount++;
      } else if (expiry < now) {
        expiredCount++;
      } else if (expiry <= sevenDaysFromNow) {
        expiringSoonCount++;
        activeCount++;
      } else {
        activeCount++;
      }
    });

    return {
      mrr,
      activeCount,
      expiringSoonCount,
      expiredCount,
      totalTenants: shops.length
    };
  }, [shops]);

  // --------------------------------------------------------------------------
  // RENEWAL DISPATCHER (+N Months with Auto-Unlock)
  // --------------------------------------------------------------------------
  const handleOpenRenewModal = (shopId: string) => {
    setRenewingShopId(shopId);
    setRenewMonths(1);
    setPaymentRefNumber('');
  };

  const handleExecuteRenewal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!renewingShopId) return;

    setIsSubmittingRenewal(true);
    try {
      const targetShop = shops.find((s) => s.id === renewingShopId);
      const currentExpiry = parseDate(targetShop?.subscriptionExpiry);
      const now = new Date();

      // If already expired, start renewal from today; otherwise extend existing expiry date
      const baseDate = currentExpiry && currentExpiry > now ? currentExpiry : now;
      const newExpiry = new Date(baseDate);
      newExpiry.setMonth(newExpiry.getMonth() + renewMonths);

      const shopRef = doc(db, 'shops', renewingShopId);
      await updateDoc(shopRef, {
        subscriptionExpiry: newExpiry,
        isLocked: false, // Auto-restore service upon payment renewal
        lastPaymentRef: paymentRefNumber.trim() || 'MANUAL_SUPER_ADMIN_RENEWAL',
        updatedAt: serverTimestamp()
      });

      toast.success(`Subscription extended by ${renewMonths} month(s). Shop is now ACTIVE.`);
      setRenewingShopId(null);
      loadSubscriptions();
    } catch (err: any) {
      console.error("Renewal failure:", err);
      toast.error(err.message || "Failed to update subscription.");
    } finally {
      setIsSubmittingRenewal(false);
    }
  };

  // Categorize shops according to expiry dates
  const filteredShops = useMemo(() => {
    const now = new Date();
    const sevenDaysFromNow = new Date();
    sevenDaysFromNow.setDate(now.getDate() + 7);

    return shops.filter((shop) => {
      const expiry = parseDate(shop.subscriptionExpiry);
      if (filter === 'ACTIVE') {
        return !expiry || expiry >= now;
      }
      if (filter === 'EXPIRING_SOON') {
        return expiry && expiry >= now && expiry <= sevenDaysFromNow;
      }
      if (filter === 'EXPIRED') {
        return expiry && expiry < now;
      }
      return true;
    });
  }, [shops, filter]);

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-300">
      
      {/* HEADER SECTION */}
      <div>
        <h1 className="text-2xl font-black text-white tracking-tight">SaaS Subscriptions & Billing</h1>
        <p className="text-xs text-slate-400 mt-1">
          Monitor your Monthly Recurring Revenue (MRR), track renewals, and manage rental licenses.
        </p>
      </div>

      {/* REVENUE & STATUS VITAL CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Estimated Monthly Revenue */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl relative overflow-hidden">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Estimated MRR</span>
            <div className="p-2 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-xl">
              <TrendingUp size={16} />
            </div>
          </div>
          <div className="text-2xl font-black text-white font-sans">{formatINR(metrics.mrr)}</div>
          <p className="text-[10px] text-slate-500 mt-1">From {metrics.activeCount} active subscribing cyber cafes</p>
        </div>

        {/* Active Licenses */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Active Tenants</span>
            <div className="p-2 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded-xl">
              <CheckCircle2 size={16} />
            </div>
          </div>
          <div className="text-2xl font-black text-white">{metrics.activeCount}</div>
          <p className="text-[10px] text-slate-500 mt-1">Out of {metrics.totalTenants} total onboarded shops</p>
        </div>

        {/* Expiring Within 7 Days */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Expiring in 7 Days</span>
            <div className="p-2 bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded-xl">
              <Clock size={16} />
            </div>
          </div>
          <div className="text-2xl font-black text-amber-400">{metrics.expiringSoonCount}</div>
          <p className="text-[10px] text-slate-500 mt-1">Requires renewal follow-up</p>
        </div>

        {/* Expired / Due */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Overdue / Expired</span>
            <div className="p-2 bg-red-500/10 text-red-400 border border-red-500/20 rounded-xl">
              <AlertTriangle size={16} />
            </div>
          </div>
          <div className="text-2xl font-black text-red-400">{metrics.expiredCount}</div>
          <p className="text-[10px] text-slate-500 mt-1">Subject to service suspension</p>
        </div>

      </div>

      {/* FILTER BUTTONS */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        {(['ALL', 'ACTIVE', 'EXPIRING_SOON', 'EXPIRED'] as const).map((key) => (
          <button
            key={key}
            onClick={() => setFilter(key)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              filter === key
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-850'
            }`}
          >
            {key.replace('_', ' ')}
          </button>
        ))}
      </div>

      {/* SUBSCRIPTION RECORDS TABLE */}
      {loading ? (
        <div className="flex flex-col items-center justify-center py-20 text-slate-400">
          <Loader2 className="w-8 h-8 text-indigo-500 animate-spin mb-3" />
          <p className="text-xs font-semibold">Calculating Platform Subscriptions...</p>
        </div>
      ) : filteredShops.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-400">
          <Calendar className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <p className="font-bold text-white text-base">No matching subscription records</p>
          <p className="text-xs text-slate-500 mt-1">Adjust filters or onboard new shops.</p>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/70 border-b border-slate-800 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                <tr>
                  <th className="py-4 px-6">Shop</th>
                  <th className="py-4 px-6">Current Plan</th>
                  <th className="py-4 px-6">Monthly Fee</th>
                  <th className="py-4 px-6">Expiry Date</th>
                  <th className="py-4 px-6">Status</th>
                  <th className="py-4 px-6 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {filteredShops.map((shop) => {
                  const tierConfig = RENTAL_TIERS[shop.rentalTier] || RENTAL_TIERS.STARTER;
                  const expiry = parseDate(shop.subscriptionExpiry);
                  const now = new Date();
                  const isExpired = expiry ? expiry < now : false;

                  return (
                    <tr key={shop.id} className="hover:bg-slate-850/50 transition-colors">
                      <td className="py-4 px-6">
                        <div className="font-bold text-white text-sm">{shop.name}</div>
                        <div className="text-[11px] text-slate-400 font-mono mt-0.5">{shop.ownerEmail}</div>
                      </td>

                      <td className="py-4 px-6">
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold bg-slate-800 text-indigo-300 border border-slate-700">
                          {shop.rentalTier}
                        </span>
                      </td>

                      <td className="py-4 px-6 font-mono font-bold text-white">
                        {formatINR(tierConfig.monthlyFee)}
                      </td>

                      <td className="py-4 px-6">
                        <div className={`font-medium ${isExpired ? 'text-red-400 font-bold' : 'text-slate-300'}`}>
                          {expiry ? formatDate(expiry) : 'Lifetime / Unset'}
                        </div>
                      </td>

                      <td className="py-4 px-6">
                        {isExpired ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-red-500/10 text-red-400 border border-red-500/30">
                            EXPIRED
                          </span>
                        ) : shop.isLocked ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30">
                            SUSPENDED
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                            ACTIVE
                          </span>
                        )}
                      </td>

                      <td className="py-4 px-6 text-right">
                        <button
                          onClick={() => handleOpenRenewModal(shop.id)}
                          className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl transition-all shadow-md shadow-indigo-600/20"
                        >
                          Renew / Extend
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* RENEWAL DIALOG */}
      {renewingShopId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <CreditCard size={18} className="text-indigo-400" />
                  Renew Subscription License
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Extends validity and auto-unlocks kiosk operations.
                </p>
              </div>
              <button
                onClick={() => setRenewingShopId(null)}
                className="text-slate-400 hover:text-white font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleExecuteRenewal} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  Renewal Period
                </label>
                <select
                  value={renewMonths}
                  onChange={(e) => setRenewMonths(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white outline-none focus:border-indigo-500 font-bold"
                >
                  <option value={1}>+1 Month Extension</option>
                  <option value={3}>+3 Months (Quarterly)</option>
                  <option value={6}>+6 Months (Half-Yearly)</option>
                  <option value={12}>+12 Months (Annual License)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  Payment Reference / UTR Number
                </label>
                <input
                  type="text"
                  placeholder="e.g. UPI Ref 324109854721"
                  value={paymentRefNumber}
                  onChange={(e) => setPaymentRefNumber(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white font-mono outline-none focus:border-indigo-500"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Enter UTR or bank transaction reference for audit tracking.
                </p>
              </div>

              <div className="pt-4 flex gap-3">
                <button
                  type="button"
                  onClick={() => setRenewingShopId(null)}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs py-3 rounded-xl transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingRenewal}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-3 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 transition-colors disabled:opacity-50"
                >
                  {isSubmittingRenewal ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle2 size={16} />}
                  {isSubmittingRenewal ? 'Processing...' : 'Confirm Renewal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
