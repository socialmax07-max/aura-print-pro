import React, { useState, useEffect } from 'react';
import { Routes, Route, Navigate, Link, useLocation } from 'react-router-dom';
import { 
  ShieldAlert, 
  ShieldCheck, 
  Building2, 
  CreditCard, 
  Activity, 
  LogOut, 
  Menu, 
  X, 
  Printer, 
  Lock, 
  CheckCircle2, 
  Loader2 
} from 'lucide-react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';

// Lazy load nested admin modules
const TenantManager = React.lazy(() => import('./TenantManager'));
const SubscriptionManager = React.lazy(() => import('./SubscriptionManager'));

interface PlatformMetrics {
  totalShops: number;
  activeShops: number;
  lockedShops: number;
  loading: boolean;
}

export default function SuperAdminApp() {
  const location = useLocation();
  const { currentUser, role, isLoading: isAuthLoading, logout } = useAuth();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [metrics, setMetrics] = useState<PlatformMetrics>({
    totalShops: 0,
    activeShops: 0,
    lockedShops: 0,
    loading: true,
  });

  // Automatically close mobile menu upon navigation
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  // Aggregate platform-level metrics across all tenants
  useEffect(() => {
    async function fetchPlatformMetrics() {
      if (role !== 'SUPER_ADMIN') return;

      try {
        const shopsSnap = await getDocs(collection(db, 'shops'));
        let active = 0;
        let locked = 0;

        shopsSnap.forEach((docSnap) => {
          const data = docSnap.data();
          if (data.isLocked) {
            locked++;
          } else {
            active++;
          }
        });

        setMetrics({
          totalShops: shopsSnap.size,
          activeShops: active,
          lockedShops: locked,
          loading: false,
        });
      } catch (err) {
        console.error("Super Admin metrics sync error:", err);
        setMetrics((prev) => ({ ...prev, loading: false }));
      }
    }

    fetchPlatformMetrics();
  }, [role]);

  // --------------------------------------------------------------------------
  // ROLE VERIFICATION & SECURITY ENFORCEMENT
  // --------------------------------------------------------------------------
  if (isAuthLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-900 text-white">
        <Loader2 className="w-10 h-10 text-indigo-400 animate-spin mb-4" />
        <p className="text-sm font-semibold tracking-wide text-slate-300">
          Verifying Super Admin Authorization...
        </p>
      </div>
    );
  }

  // Enforce Super Admin role verification
  if (!currentUser || role !== 'SUPER_ADMIN') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 p-4">
        <div className="bg-slate-900 border border-red-500/30 rounded-2xl p-8 max-w-md w-full text-center shadow-2xl">
          <ShieldAlert className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-black text-white mb-2">Restricted Access</h2>
          <p className="text-sm text-slate-400 mb-6 leading-relaxed">
            This area is restricted to the platform owner. Unauthorized access attempts are monitored and recorded.
          </p>
          <div className="flex gap-3 justify-center">
            <button
              onClick={() => window.location.href = '/login'}
              className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl transition-colors"
            >
              Back to Login
            </button>
            {currentUser && (
              <button
                onClick={logout}
                className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl transition-colors"
              >
                Sign Out
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  const navItems = [
    { name: 'Tenants & Shops', path: '/admin', icon: Building2 },
    { name: 'Rental Plans & Subscriptions', path: '/admin/subscriptions', icon: CreditCard },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex">
      
      {/* Mobile Drawer Backdrop */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/70 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* SUPER ADMIN SIDEBAR */}
      <aside className={cn(
        "fixed lg:sticky top-0 left-0 z-50 h-screen w-72 bg-slate-900 border-r border-slate-800 flex flex-col transition-transform duration-300 ease-in-out",
        isMobileMenuOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        {/* Brand Bar */}
        <div className="h-16 flex items-center justify-between px-6 border-b border-slate-800 bg-slate-950/40">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 rounded-xl">
              <Printer size={20} />
            </div>
            <div>
              <span className="font-black text-white text-base tracking-tight block">AURA Print Pro</span>
              <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest">Super Admin</span>
            </div>
          </div>
          <button 
            className="lg:hidden text-slate-400 hover:text-white"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <X size={22} />
          </button>
        </div>

        {/* Navigation */}
        <div className="p-5 flex-1">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-3 mb-3">
            Platform Core
          </div>
          <nav className="space-y-1.5">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path || 
                (item.path === '/admin' && location.pathname === '/admin/');

              return (
                <Link
                  key={item.name}
                  to={item.path}
                  className={cn(
                    "flex items-center gap-3 px-3.5 py-3 rounded-xl text-xs font-bold transition-all duration-200",
                    isActive
                      ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/30"
                      : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"
                  )}
                >
                  <Icon size={18} className={isActive ? "text-white" : "text-slate-400"} />
                  {item.name}
                </Link>
              );
            })}
          </nav>

          {/* Quick Platform Vitals Card */}
          <div className="mt-8 p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-400 mb-3">
              <Activity size={14} className="text-emerald-400 animate-pulse" />
              <span>Platform Health</span>
            </div>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between items-center text-slate-400">
                <span>Active Cyber Cafes</span>
                <span className="font-mono font-bold text-emerald-400">{metrics.activeShops}</span>
              </div>
              <div className="flex justify-between items-center text-slate-400">
                <span>Locked / Suspended</span>
                <span className="font-mono font-bold text-red-400">{metrics.lockedShops}</span>
              </div>
              <div className="flex justify-between items-center text-slate-400 pt-1 border-t border-slate-800">
                <span>Total Registered</span>
                <span className="font-mono font-bold text-white">{metrics.totalShops}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Authenticated Admin Identity */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/30">
          <div className="flex items-center gap-3 mb-3 px-2">
            <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center font-black text-white text-sm">
              S
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-white truncate">Sabir Ansari</p>
              <p className="text-[11px] text-emerald-400 flex items-center gap-1 font-semibold">
                <ShieldCheck size={12} /> Root Super Admin
              </p>
            </div>
          </div>
          <button
            onClick={logout}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-bold text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition-colors"
          >
            <LogOut size={16} /> Exit Super Admin
          </button>
        </div>
      </aside>

      {/* MAIN ADMIN WORKSPACE */}
      <main className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        {/* Mobile Header Bar */}
        <header className="lg:hidden h-16 bg-slate-900 border-b border-slate-800 flex items-center justify-between px-4 shrink-0">
          <div className="flex items-center gap-2 font-bold text-white text-sm">
            <Printer size={18} className="text-indigo-400" />
            <span>AURA Super Admin</span>
          </div>
          <button 
            onClick={() => setIsMobileMenuOpen(true)}
            className="p-2 text-slate-400 hover:text-white rounded-lg"
          >
            <Menu size={22} />
          </button>
        </header>

        {/* Scrollable View Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <React.Suspense fallback={
            <div className="flex flex-col items-center justify-center h-64 text-slate-400">
              <Loader2 className="w-8 h-8 text-indigo-500 animate-spin mb-3" />
              <p className="text-xs font-medium">Loading Workspace Module...</p>
            </div>
          }>
            <Routes>
              <Route index element={<TenantManager />} />
              <Route path="subscriptions" element={<SubscriptionManager />} />
              <Route path="*" element={<Navigate to="/admin" replace />} />
            </Routes>
          </React.Suspense>
        </div>
      </main>

    </div>
  );
}
