import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Plus, 
  Search, 
  Lock, 
  Unlock, 
  ExternalLink, 
  Copy, 
  Check, 
  ShieldCheck, 
  AlertCircle, 
  Loader2, 
  Calendar,
  Layers,
  Sparkles
} from 'lucide-react';
import { 
  collection, 
  getDocs, 
  doc, 
  setDoc, 
  updateDoc, 
  serverTimestamp, 
  query, 
  orderBy 
} from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { toast } from 'sonner';
import { formatDate } from '@/lib/utils';

// The 5 Standard Commercial Rental Plans
export type RentalPlan = 'STARTER' | 'GROWTH' | 'PRO' | 'BUSINESS' | 'ENTERPRISE';

export interface RentalTierConfig {
  name: RentalPlan;
  monthlyFee: number;
  label: string;
  maxPrinters: number;
  features: string[];
}

export const RENTAL_TIERS: Record<RentalPlan, RentalTierConfig> = {
  STARTER: {
    name: 'STARTER',
    monthlyFee: 299,
    label: 'Starter (₹299/mo)',
    maxPrinters: 1,
    features: ['Single Printer', '100MB Uploads', 'Browser Print Fallback']
  },
  GROWTH: {
    name: 'GROWTH',
    monthlyFee: 599,
    label: 'Growth (₹599/mo)',
    maxPrinters: 2,
    features: ['2 Printers', 'Direct Dynamic UPI QR', 'Priority Queue']
  },
  PRO: {
    name: 'PRO',
    monthlyFee: 999,
    label: 'Pro Studio (₹999/mo)',
    maxPrinters: 5,
    features: ['Passport Photo Studio', 'Silent QZ Tray Bridge', '5 Printers']
  },
  BUSINESS: {
    name: 'BUSINESS',
    monthlyFee: 1499,
    label: 'Business (₹1,499/mo)',
    maxPrinters: 10,
    features: ['Staff Access Management', 'Custom Rate Presets', 'Audit Logging']
  },
  ENTERPRISE: {
    name: 'ENTERPRISE',
    monthlyFee: 2499,
    label: 'Enterprise (₹2,499/mo)',
    maxPrinters: 99,
    features: ['Multi-Branch Support', 'Dedicated SLA', 'Zero Downtime Guarantee']
  }
};

interface ShopRecord {
  id: string;
  name: string;
  ownerEmail: string;
  upiId: string;
  isLocked: boolean;
  rentalTier: RentalPlan;
  subscriptionExpiry: any;
  createdAt: any;
  rates: {
    bwSingle: number;
    bwDuplex: number;
    colorSingle: number;
    colorDuplex: number;
  };
}

export default function TenantManager() {
  const [shops, setShops] = useState<ShopRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [updatingShopId, setUpdatingShopId] = useState<string | null>(null);

  // New Shop Form State
  const [newShopSlug, setNewShopSlug] = useState('');
  const [newShopName, setNewShopName] = useState('');
  const [newOwnerEmail, setNewOwnerEmail] = useState('');
  const [newUpiId, setNewUpiId] = useState('');
  const [newRentalTier, setNewRentalTier] = useState<RentalPlan>('PRO');
  const [newValidityMonths, setNewValidityMonths] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch all registered shops
  const fetchShops = async () => {
    setLoading(true);
    try {
      const q = query(collection(db, 'shops'), orderBy('createdAt', 'desc'));
      const querySnapshot = await getDocs(q);
      const items: ShopRecord[] = [];
      querySnapshot.forEach((docSnap) => {
        items.push({ id: docSnap.id, ...docSnap.data() } as ShopRecord);
      });
      setShops(items);
    } catch (err) {
      console.error("Failed to load shops:", err);
      toast.error("Failed to fetch registered cyber cafes.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchShops();
  }, []);

  // --------------------------------------------------------------------------
  // ACTIONS: REMOTE LOCK SWITCH & TIER UPDATES
  // --------------------------------------------------------------------------
  
  const handleToggleLock = async (shop: ShopRecord) => {
    const nextStatus = !shop.isLocked;
    const actionLabel = nextStatus ? 'LOCK (suspend service)' : 'UNLOCK (restore service)';
    
    if (!window.confirm(`Are you sure you want to ${actionLabel} for "${shop.name}"?`)) {
      return;
    }

    setUpdatingShopId(shop.id);
    try {
      const shopRef = doc(db, 'shops', shop.id);
      await updateDoc(shopRef, {
        isLocked: nextStatus,
        updatedAt: serverTimestamp()
      });

      setShops((prev) => 
        prev.map((s) => (s.id === shop.id ? { ...s, isLocked: nextStatus } : s))
      );

      toast.success(`Shop "${shop.name}" has been ${nextStatus ? 'LOCKED' : 'UNLOCKED'}.`);
    } catch (err) {
      console.error("Lock toggle error:", err);
      toast.error("Failed to modify shop status.");
    } finally {
      setUpdatingShopId(null);
    }
  };

  const handleTierChange = async (shopId: string, newTier: RentalPlan) => {
    setUpdatingShopId(shopId);
    try {
      const shopRef = doc(db, 'shops', shopId);
      await updateDoc(shopRef, {
        rentalTier: newTier,
        updatedAt: serverTimestamp()
      });

      setShops((prev) => 
        prev.map((s) => (s.id === shopId ? { ...s, rentalTier: newTier } : s))
      );

      toast.success(`Plan updated to ${newTier} for this tenant.`);
    } catch (err) {
      console.error("Tier change error:", err);
      toast.error("Failed to update plan.");
    } finally {
      setUpdatingShopId(null);
    }
  };

  const handleCopyLink = (shopId: string) => {
    const url = `${window.location.origin}/s/${shopId}`;
    navigator.clipboard.writeText(url);
    setCopiedId(shopId);
    toast.success("Kiosk customer URL copied to clipboard!");
    setTimeout(() => setCopiedId(null), 2500);
  };

  // --------------------------------------------------------------------------
  // ONBOARDING NEW TENANT
  // --------------------------------------------------------------------------
  
  const handleCreateShop = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanSlug = newShopSlug.toLowerCase().trim().replace(/[^a-z0-9-]/g, '-');

    if (!cleanSlug || cleanSlug.length < 3) {
      toast.error("Shop identifier must be at least 3 alphanumeric characters.");
      return;
    }

    if (!newUpiId.includes('@')) {
      toast.error("Enter a valid merchant UPI address (e.g. cafe@upi).");
      return;
    }

    setIsSubmitting(true);
    try {
      const shopRef = doc(db, 'shops', cleanSlug);
      
      // Calculate expiry date
      const expiryDate = new Date();
      expiryDate.setMonth(expiryDate.getMonth() + newValidityMonths);

      const initialShopData = {
        name: newShopName.trim(),
        ownerEmail: newOwnerEmail.trim().toLowerCase(),
        upiId: newUpiId.trim(),
        isLocked: false,
        rentalTier: newRentalTier,
        subscriptionExpiry: expiryDate,
        rates: {
          bwSingle: 2,
          bwDuplex: 3,
          colorSingle: 10,
          colorDuplex: 16
        },
        settings: {
          allowColor: true,
          allowDuplex: true,
          maxFileSizeMb: 100
        },
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      await setDoc(shopRef, initialShopData);

      toast.success(`Tenant "${newShopName}" provisioned successfully!`);
      setIsCreateModalOpen(false);

      // Reset form fields
      setNewShopSlug('');
      setNewShopName('');
      setNewOwnerEmail('');
      setNewUpiId('');
      setNewRentalTier('PRO');
      setNewValidityMonths(1);

      fetchShops();
    } catch (err: any) {
      console.error("Shop creation error:", err);
      toast.error(err.message || "Failed to create shop.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filter list
  const filteredShops = shops.filter((s) => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.ownerEmail.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-300">
      
      {/* HEADER SECTION */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight">Tenants & Cyber Cafes</h1>
          <p className="text-xs text-slate-400 mt-1">
            Provision shops, monitor subscriptions, and trigger remote kill-switches.
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold px-4 py-3 rounded-xl flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition-all self-start sm:self-auto"
        >
          <Plus size={16} /> Onboard New Shop
        </button>
      </div>

      {/* SEARCH AND FILTERS */}
      <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-2xl flex items-center gap-3">
        <Search className="w-5 h-5 text-slate-400 shrink-0" />
        <input
          type="text"
          placeholder="Search by shop name, clean ID, or owner email..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="bg-transparent border-none text-white text-sm focus:outline-none w-full placeholder:text-slate-500"
        />
      </div>

      {/* TENANTS TABLE */}
      {loading ? (
        <div className="flex flex-col items-center justify-center py-24 text-slate-400">
          <Loader2 className="w-8 h-8 text-indigo-500 animate-spin mb-3" />
          <p className="text-xs font-semibold">Loading Tenant Network...</p>
        </div>
      ) : filteredShops.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-400">
          <Building2 className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <p className="font-bold text-white text-base">No cyber cafes found</p>
          <p className="text-xs text-slate-500 mt-1">Get started by creating your first tenant.</p>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/70 border-b border-slate-800 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                <tr>
                  <th className="py-4 px-6">Shop & Clean URL</th>
                  <th className="py-4 px-6">Owner / Contact</th>
                  <th className="py-4 px-6">Rental Plan</th>
                  <th className="py-4 px-6">Status / Lock</th>
                  <th className="py-4 px-6 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {filteredShops.map((shop) => {
                  const isUpdating = updatingShopId === shop.id;
                  const tierConfig = RENTAL_TIERS[shop.rentalTier] || RENTAL_TIERS.STARTER;

                  return (
                    <tr key={shop.id} className="hover:bg-slate-850/50 transition-colors">
                      {/* Shop Name & Slug */}
                      <td className="py-4 px-6">
                        <div className="font-bold text-white text-sm">{shop.name}</div>
                        <div className="text-[11px] text-indigo-400 font-mono mt-0.5 flex items-center gap-1.5">
                          <span>/s/{shop.id}</span>
                          <button
                            onClick={() => handleCopyLink(shop.id)}
                            className="text-slate-400 hover:text-white transition-colors"
                            title="Copy customer link"
                          >
                            {copiedId === shop.id ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                          </button>
                        </div>
                      </td>

                      {/* Owner Email & UPI */}
                      <td className="py-4 px-6">
                        <div className="text-slate-200 font-medium">{shop.ownerEmail}</div>
                        <div className="text-[11px] text-slate-400 font-mono mt-0.5">UPI: {shop.upiId}</div>
                      </td>

                      {/* Rental Tier Selector */}
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-2">
                          <select
                            value={shop.rentalTier}
                            disabled={isUpdating}
                            onChange={(e) => handleTierChange(shop.id, e.target.value as RentalPlan)}
                            className="bg-slate-950 border border-slate-700 text-white text-xs rounded-lg px-2.5 py-1.5 font-bold outline-none focus:border-indigo-500"
                          >
                            {Object.keys(RENTAL_TIERS).map((tierKey) => (
                              <option key={tierKey} value={tierKey}>
                                {tierKey} (₹{RENTAL_TIERS[tierKey as RentalPlan].monthlyFee}/mo)
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="text-[10px] text-slate-400 mt-1">
                          Max {tierConfig.maxPrinters} Printer(s)
                        </div>
                      </td>

                      {/* Lock / Active Status */}
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-2">
                          {shop.isLocked ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-red-500/10 text-red-400 border border-red-500/30">
                              <Lock size={12} /> LOCKED
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                              <Unlock size={12} /> ACTIVE
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Actions: Toggle Kill Switch & Visit Links */}
                      <td className="py-4 px-6 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {/* Remote Kill-Switch */}
                          <button
                            onClick={() => handleToggleLock(shop)}
                            disabled={isUpdating}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 ${
                              shop.isLocked
                                ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                                : 'bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30'
                            }`}
                            title={shop.isLocked ? "Restore kiosk operations" : "Suspend kiosk immediately"}
                          >
                            {shop.isLocked ? <Unlock size={13} /> : <Lock size={13} />}
                            {shop.isLocked ? 'Unlock' : 'Lock'}
                          </button>

                          {/* Kiosk URL View */}
                          <a
                            href={`/s/${shop.id}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                            title="Open Customer Kiosk"
                          >
                            <ExternalLink size={14} />
                          </a>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* CREATE NEW SHOP MODAL */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 max-w-xl w-full shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Building2 size={20} className="text-indigo-400" />
                  Onboard Cyber Cafe / CSC
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Creates dedicated Firestore tenant path and isolated storage partition.
                </p>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="text-slate-400 hover:text-white text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateShop} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  Unique Slug / URL Path <span className="text-indigo-400">*</span>
                </label>
                <div className="flex items-center bg-slate-950 border border-slate-800 rounded-xl px-3 focus-within:border-indigo-500">
                  <span className="text-slate-500 text-xs font-mono">/s/</span>
                  <input
                    type="text"
                    required
                    placeholder="ansari-telecom"
                    value={newShopSlug}
                    onChange={(e) => setNewShopSlug(e.target.value)}
                    className="w-full bg-transparent p-2.5 text-xs text-white font-mono outline-none"
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Example: <code>ansari-telecom</code> creates kiosk at <code>/s/ansari-telecom</code>
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  Shop Display Name <span className="text-indigo-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ansari Cyber Cafe & CSC Center"
                  value={newShopName}
                  onChange={(e) => setNewShopName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                    Owner Email <span className="text-indigo-400">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="owner@gmail.com"
                    value={newOwnerEmail}
                    onChange={(e) => setNewOwnerEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                    Merchant UPI ID <span className="text-indigo-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="9876543210@paytm"
                    value={newUpiId}
                    onChange={(e) => setNewUpiId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white font-mono outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                    SaaS Rental Tier
                  </label>
                  <select
                    value={newRentalTier}
                    onChange={(e) => setNewRentalTier(e.target.value as RentalPlan)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white outline-none focus:border-indigo-500"
                  >
                    {Object.keys(RENTAL_TIERS).map((k) => (
                      <option key={k} value={k}>
                        {RENTAL_TIERS[k as RentalPlan].label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                    Initial Validity
                  </label>
                  <select
                    value={newValidityMonths}
                    onChange={(e) => setNewValidityMonths(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white outline-none focus:border-indigo-500"
                  >
                    <option value={1}>1 Month</option>
                    <option value={3}>3 Months</option>
                    <option value={6}>6 Months</option>
                    <option value={12}>12 Months (Annual)</option>
                  </select>
                </div>
              </div>

              <div className="pt-4 flex gap-3">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs py-3 rounded-xl transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs py-3 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 transition-colors disabled:opacity-50"
                >
                  {isSubmitting ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
                  {isSubmitting ? 'Creating...' : 'Provision Tenant'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}