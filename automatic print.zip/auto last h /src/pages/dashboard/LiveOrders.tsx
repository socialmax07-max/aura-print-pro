import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { collection, query, orderBy, onSnapshot, doc, updateDoc, serverTimestamp, limit } from 'firebase/firestore';
import { 
  CheckCircle, 
  XCircle, 
  Printer, 
  AlertTriangle, 
  Clock, 
  ExternalLink,
  IndianRupee,
  RefreshCw,
  Search
} from 'lucide-react';
import { toast } from 'sonner';

import { db } from '@/lib/firebase/config';
import { OrderSnapshot } from '@/lib/validations/zodSchemas';
import { formatINR, formatDate } from '@/lib/utils';

export default function LiveOrders() {
  const { shopId } = useParams<{ shopId: string }>();
  const [orders, setOrders] = useState<OrderSnapshot[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [isProcessingId, setIsProcessingId] = useState<string | null>(null);

  // Real-time listener for the shop's recent orders
  useEffect(() => {
    if (!shopId) return;

    // Fetch the 50 most recent orders to keep the dashboard snappy and memory-efficient.
    // In-memory filtering is used below for tabs (Action Required vs Queued).
    const ordersRef = collection(db, 'shops', shopId, 'orders');
    const q = query(ordersRef, orderBy('createdAt', 'desc'), limit(50));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedOrders: OrderSnapshot[] = [];
      snapshot.forEach((docSnap) => {
        fetchedOrders.push({ id: docSnap.id, ...docSnap.data() } as OrderSnapshot);
      });
      setOrders(fetchedOrders);
      setLoading(false);
    }, (error) => {
      console.error("Dashboard queue error:", error);
      toast.error("Failed to sync live orders. Please refresh.");
      setLoading(false);
    });

    return () => unsubscribe();
  }, [shopId]);

  // ------------------------------------------------------------------
  // STATE TRANSITIONS (Strictly validated by firestore.rules backend)
  // ------------------------------------------------------------------
  
  const handleApprovePayment = async (orderId: string) => {
    if (!shopId) return;
    setIsProcessingId(orderId);
    try {
      const orderRef = doc(db, 'shops', shopId, 'orders', orderId);
      await updateDoc(orderRef, {
        status: 'QUEUED',
        updatedAt: serverTimestamp()
      });
      toast.success("Payment verified! Sent to print queue.");
    } catch (err) {
      toast.error("Failed to approve payment. Permission denied.");
    } finally {
      setIsProcessingId(null);
    }
  };

  const handleRejectPayment = async (orderId: string) => {
    if (!shopId) return;
    if (!window.confirm("Are you sure you want to REJECT this order? The customer will see a failure message.")) return;
    
    setIsProcessingId(orderId);
    try {
      const orderRef = doc(db, 'shops', shopId, 'orders', orderId);
      await updateDoc(orderRef, {
        status: 'REJECTED',
        updatedAt: serverTimestamp()
      });
      toast.success("Order rejected successfully.");
    } catch (err) {
      toast.error("Failed to reject order.");
    } finally {
      setIsProcessingId(null);
    }
  };

  const handleMarkPrinted = async (orderId: string) => {
    if (!shopId) return;
    setIsProcessingId(orderId);
    try {
      const orderRef = doc(db, 'shops', shopId, 'orders', orderId);
      await updateDoc(orderRef, {
        status: 'PRINTED',
        updatedAt: serverTimestamp()
      });
      toast.success("Job marked as completed.");
    } catch (err) {
      toast.error("Failed to update status.");
    } finally {
      setIsProcessingId(null);
    }
  };

  // ------------------------------------------------------------------
  // FILTERING & CATEGORIZATION
  // ------------------------------------------------------------------
  
  const filteredOrders = orders.filter(o => 
    (o.shortRef?.toLowerCase().includes(searchQuery.toLowerCase()) || 
     o.fileName.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const verificationQueue = filteredOrders.filter(o => o.status === 'PAYMENT_VERIFYING');
  const printQueue = filteredOrders.filter(o => o.status === 'QUEUED' || o.status === 'PRINTING');
  const completedHistory = filteredOrders.filter(o => o.status === 'PRINTED' || o.status === 'REJECTED' || o.status === 'PRINT_FAILED');

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <RefreshCw className="w-8 h-8 text-brand-500 animate-spin" />
      </div>
    );
  }

  // Sub-component for rendering a single order card cleanly
  const OrderCard = ({ order, type }: { order: OrderSnapshot, type: 'VERIFY' | 'PRINT' | 'HISTORY' }) => (
    <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold bg-gray-100 text-gray-700 mb-2">
            Ref: {order.shortRef || order.id.substring(0,6)}
          </span>
          <h3 className="font-semibold text-gray-900 line-clamp-1" title={order.fileName}>
            {order.fileName}
          </h3>
          <p className="text-xs text-gray-500 mt-1">
            {formatDate(order.createdAt?.toDate ? order.createdAt.toDate() : order.createdAt)}
          </p>
        </div>
        <div className="text-right">
          <p className="text-xl font-black text-brand-700">{formatINR(order.amount)}</p>
          <span className={`inline-flex items-center gap-1 mt-1 text-xs font-bold ${order.paymentMethod === 'UPI' ? 'text-blue-600' : 'text-orange-600'}`}>
            {order.paymentMethod === 'UPI' ? <IndianRupee size={12}/> : <CheckCircle size={12}/>}
            {order.paymentMethod}
          </span>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg p-3 text-sm text-gray-600 grid grid-cols-2 gap-2 mb-4">
        <div><span className="text-gray-400">Pages:</span> {order.config.selectedPages}</div>
        <div><span className="text-gray-400">Copies:</span> {order.config.copies}</div>
        <div><span className="text-gray-400">Color:</span> {order.config.isColor ? 'Yes' : 'B&W'}</div>
        <div><span className="text-gray-400">Sides:</span> {order.config.isDuplex ? 'Double' : 'Single'}</div>
      </div>

      {type === 'VERIFY' && (
        <div className="flex gap-3">
          <button 
            onClick={() => handleApprovePayment(order.id!)}
            disabled={isProcessingId === order.id}
            className="flex-1 bg-green-500 hover:bg-green-600 text-white font-semibold py-2.5 rounded-lg flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
          >
            <CheckCircle size={18} /> Approve
          </button>
          <button 
            onClick={() => handleRejectPayment(order.id!)}
            disabled={isProcessingId === order.id}
            className="flex-1 bg-white border border-red-200 text-red-600 hover:bg-red-50 font-semibold py-2.5 rounded-lg flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
          >
            <XCircle size={18} /> Reject
          </button>
        </div>
      )}

      {type === 'PRINT' && (
        <div className="flex gap-3">
          <a 
            href={order.fileUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 bg-brand-500 hover:bg-brand-600 text-white font-semibold py-2.5 rounded-lg flex items-center justify-center gap-2 transition-colors"
          >
            <Printer size={18} /> Print Now
          </a>
          <button 
            onClick={() => handleMarkPrinted(order.id!)}
            disabled={isProcessingId === order.id}
            className="flex-1 bg-white border border-gray-200 text-gray-700 hover:bg-gray-50 font-semibold py-2.5 rounded-lg flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
          >
            <CheckCircle size={18} /> Done
          </button>
        </div>
      )}

      {type === 'HISTORY' && (
        <div className={`text-center py-2 rounded-lg font-semibold text-sm border ${
          order.status === 'PRINTED' ? 'bg-green-50 text-green-700 border-green-200' : 
          'bg-red-50 text-red-700 border-red-200'
        }`}>
          Status: {order.status.replace('_', ' ')}
        </div>
      )}
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto pb-12 animate-in fade-in duration-500">
      
      {/* Header & Search */}
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Live Orders</h1>
          <p className="text-gray-500">Manage incoming prints and verify payments.</p>
        </div>
        
        <div className="relative w-full md:w-72">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input 
            type="text" 
            placeholder="Search Reference or Filename..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* ACTION REQUIRED COLUMN (Verifications) */}
        <div>
          <div className="flex items-center justify-between mb-4 border-b border-gray-200 pb-2">
            <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
              <AlertTriangle className="text-orange-500 w-5 h-5" />
              Requires Verification
            </h2>
            <span className="bg-orange-100 text-orange-700 py-0.5 px-2.5 rounded-full text-xs font-bold">
              {verificationQueue.length}
            </span>
          </div>
          
          {verificationQueue.length === 0 ? (
            <div className="bg-white rounded-xl border border-dashed border-gray-300 p-8 text-center text-gray-500">
              <CheckCircle className="w-8 h-8 text-gray-300 mx-auto mb-2" />
              No pending verifications.
            </div>
          ) : (
            <div className="space-y-4">
              {verificationQueue.map(order => <OrderCard key={order.id} order={order} type="VERIFY" />)}
            </div>
          )}
        </div>

        {/* PRINT QUEUE COLUMN */}
        <div>
          <div className="flex items-center justify-between mb-4 border-b border-gray-200 pb-2">
            <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
              <Printer className="text-brand-500 w-5 h-5" />
              Print Queue
            </h2>
            <span className="bg-brand-100 text-brand-700 py-0.5 px-2.5 rounded-full text-xs font-bold">
              {printQueue.length}
            </span>
          </div>
          
          {printQueue.length === 0 ? (
            <div className="bg-white rounded-xl border border-dashed border-gray-300 p-8 text-center text-gray-500">
              <Clock className="w-8 h-8 text-gray-300 mx-auto mb-2" />
              Print queue is empty.
            </div>
          ) : (
            <div className="space-y-4">
              {printQueue.map(order => <OrderCard key={order.id} order={order} type="PRINT" />)}
            </div>
          )}
        </div>

      </div>

      {/* RECENT HISTORY PREVIEW */}
      <div className="mt-12">
        <h2 className="text-lg font-bold text-gray-900 mb-4 border-b border-gray-200 pb-2">Recent History</h2>
        {completedHistory.length === 0 ? (
          <p className="text-sm text-gray-500">No recent history.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 opacity-75">
            {completedHistory.slice(0, 6).map(order => <OrderCard key={order.id} order={order} type="HISTORY" />)}
          </div>
        )}
      </div>

    </div>
  );
}
