import React, { useState, useEffect, useCallback, useRef } from 'react';
import qz from 'qz-tray';
import { 
  Printer, 
  Wifi, 
  WifiOff, 
  RefreshCw, 
  AlertTriangle, 
  Play, 
  CheckCircle2, 
  FileText, 
  ExternalLink 
} from 'lucide-react';
import { toast } from 'sonner';
import { doc, updateDoc, serverTimestamp, addDoc, collection } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { OrderSnapshot } from '@/lib/validations/zodSchemas';

interface PrintQueueManagerProps {
  shopId: string;
  queuedOrders: OrderSnapshot[];
}

type BridgeStatus = 'CHECKING' | 'CONNECTED' | 'DISCONNECTED' | 'ERROR';

export default function PrintQueueManager({ shopId, queuedOrders }: PrintQueueManagerProps) {
  const [bridgeStatus, setBridgeStatus] = useState<BridgeStatus>('CHECKING');
  const [printers, setPrinters] = useState<string[]>([]);
  const [selectedPrinter, setSelectedPrinter] = useState<string>(() => {
    return localStorage.getItem(`aura_printer_${shopId}`) || '';
  });
  const [isPrintingOrderId, setIsPrintingOrderId] = useState<string | null>(null);
  const [bridgeError, setBridgeError] = useState<string | null>(null);

  // Mutex lock to prevent duplicate concurrent prints of the same job
  const inFlightJobsRef = useRef<Set<string>>(new Set());

  // Connect to Local QZ Tray WebSocket Bridge
  const connectBridge = useCallback(async () => {
    setBridgeStatus('CHECKING');
    setBridgeError(null);

    try {
      if (qz.websocket.isActive()) {
        setBridgeStatus('CONNECTED');
        const printerList = await qz.printers.find();
        setPrinters(printerList);
        return;
      }

      await qz.websocket.connect({
        retries: 2,
        delay: 1,
      });

      setBridgeStatus('CONNECTED');
      const printerList = await qz.printers.find();
      setPrinters(printerList);

      // Auto-select first printer or keep saved preference
      const saved = localStorage.getItem(`aura_printer_${shopId}`);
      if (saved && printerList.includes(saved)) {
        setSelectedPrinter(saved);
      } else if (printerList.length > 0) {
        setSelectedPrinter(printerList[0]);
        localStorage.setItem(`aura_printer_${shopId}`, printerList[0]);
      }
    } catch (err: any) {
      console.warn("QZ Tray connection failed:", err);
      setBridgeStatus('DISCONNECTED');
      setBridgeError(
        "Local Print Bridge is not running on this PC. Start QZ Tray or use Browser Print Fallback."
      );
    }
  }, [shopId]);

  useEffect(() => {
    connectBridge();

    return () => {
      if (qz.websocket.isActive()) {
        qz.websocket.disconnect().catch(() => {});
      }
    };
  }, [connectBridge]);

  const handlePrinterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    setSelectedPrinter(val);
    localStorage.setItem(`aura_printer_${shopId}`, val);
  };

  // Safe Print Dispatcher
  const executePrintJob = async (order: OrderSnapshot) => {
    if (!order.id) return;

    if (inFlightJobsRef.current.has(order.id)) {
      toast.warning("Job is already being sent to printer. Please wait.");
      return;
    }

    if (!selectedPrinter || bridgeStatus !== 'CONNECTED') {
      toast.error("Printer Bridge is offline. Please use Browser Print or connect QZ Tray.");
      return;
    }

    inFlightJobsRef.current.add(order.id);
    setIsPrintingOrderId(order.id);

    const orderRef = doc(db, 'shops', shopId, 'orders', order.id);

    try {
      // 1. Evidence State 1: Mark job as actively PRINTING
      await updateDoc(orderRef, {
        status: 'PRINTING',
        updatedAt: serverTimestamp(),
      });

      // 2. Configure QZ Tray parameters
      const config = qz.configs.create(selectedPrinter, {
        copies: order.config.copies || 1,
        colorType: order.config.isColor ? 'color' : 'grayscale',
        duplex: order.config.isDuplex ? 'long-edge' : false,
      });

      // 3. Send PDF payload to physical Windows spooler
      const data = [
        {
          type: 'pixel',
          format: 'pdf',
          flavor: 'file',
          data: order.fileUrl,
        },
      ];

      await qz.print(config, data);

      // 4. Evidence State 2: Print acknowledged by spooler -> Mark PRINTED
      await updateDoc(orderRef, {
        status: 'PRINTED',
        updatedAt: serverTimestamp(),
      });

      // Audit Log for diagnostic tracking
      await addDoc(collection(db, 'shops', shopId, 'printer_logs'), {
        orderId: order.id,
        printer: selectedPrinter,
        status: 'SUCCESS',
        timestamp: serverTimestamp(),
      });

      toast.success(`Job ${order.shortRef || order.id.slice(0, 6)} sent to ${selectedPrinter}`);
    } catch (err: any) {
      console.error("Print spooler error:", err);

      // Disconnected printer does NOT discard paid order - mark PRINT_FAILED for review
      await updateDoc(orderRef, {
        status: 'PRINT_FAILED',
        updatedAt: serverTimestamp(),
      });

      await addDoc(collection(db, 'shops', shopId, 'printer_logs'), {
        orderId: order.id,
        printer: selectedPrinter,
        status: 'FAILED',
        errorMessage: err?.message || 'Unknown spooler error',
        timestamp: serverTimestamp(),
      });

      toast.error(`Spooler Error: ${err?.message || 'Printer not responding. Use Browser Fallback.'}`);
    } finally {
      inFlightJobsRef.current.delete(order.id);
      setIsPrintingOrderId(null);
    }
  };

  // Safe Browser Fallback for printing without QZ Tray
  const triggerBrowserPrint = (fileUrl: string) => {
    const printWindow = window.open(fileUrl, '_blank');
    if (printWindow) {
      printWindow.focus();
    } else {
      toast.error("Pop-up blocked. Please allow pop-ups for this site.");
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm mb-8">
      
      {/* BRIDGE DIAGNOSTICS BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-5 border-b border-gray-100 gap-4">
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-xl ${bridgeStatus === 'CONNECTED' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
            <Printer size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-bold text-gray-900">Hardware Print Bridge</h2>
              <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold ${
                bridgeStatus === 'CONNECTED' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
              }`}>
                {bridgeStatus === 'CONNECTED' ? <Wifi size={12} /> : <WifiOff size={12} />}
                {bridgeStatus}
              </span>
            </div>
            <p className="text-xs text-gray-500 mt-0.5">
              Windows Local Service: {bridgeStatus === 'CONNECTED' ? 'Ready for silent direct spooling' : 'Offline (Browser Fallback Active)'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {bridgeStatus === 'CONNECTED' ? (
            <select
              value={selectedPrinter}
              onChange={handlePrinterChange}
              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-xl p-2.5 font-medium outline-none focus:ring-2 focus:ring-brand-500"
            >
              {printers.map((p) => (
                <option key={p} value={p}>{p}</option>
              ))}
            </select>
          ) : (
            <button
              onClick={connectBridge}
              className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold text-xs px-3 py-2 rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <RefreshCw size={14} /> Retry Bridge
            </button>
          )}
        </div>
      </div>

      {bridgeError && (
        <div className="mt-4 bg-amber-50 border border-amber-200 rounded-xl p-3.5 flex items-start gap-3 text-amber-900 text-xs">
          <AlertTriangle size={16} className="text-amber-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-bold">Windows Bridge Disconnected</p>
            <p className="mt-0.5">{bridgeError}</p>
          </div>
        </div>
      )}

      {/* ACTIVE PRINT JOBS QUEUE */}
      <div className="mt-6">
        <h3 className="text-sm font-bold text-gray-700 uppercase tracking-wider mb-3">
          Active Jobs Ready for Output ({queuedOrders.length})
        </h3>

        {queuedOrders.length === 0 ? (
          <div className="text-center py-6 text-gray-400 text-sm border border-dashed rounded-xl">
            No approved jobs awaiting print spooler.
          </div>
        ) : (
          <div className="space-y-3">
            {queuedOrders.map((order) => {
              const isPrinting = isPrintingOrderId === order.id;

              return (
                <div 
                  key={order.id} 
                  className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-gray-50 rounded-xl border border-gray-200 gap-4"
                >
                  <div className="flex items-start gap-3">
                    <FileText className="w-5 h-5 text-gray-500 shrink-0 mt-0.5" />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-gray-900 text-sm">{order.fileName}</span>
                        <span className="text-xs font-semibold px-2 py-0.5 rounded bg-gray-200 text-gray-700">
                          Ref: {order.shortRef || order.id?.slice(0, 6)}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        {order.config.selectedPages} Pages • {order.config.copies} Copies • {order.config.isColor ? 'Color' : 'B&W'} • {order.config.isDuplex ? 'Duplex' : 'Single'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {/* Hardware bridge trigger */}
                    {bridgeStatus === 'CONNECTED' ? (
                      <button
                        onClick={() => executePrintJob(order)}
                        disabled={isPrinting}
                        className="bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs px-4 py-2.5 rounded-lg flex items-center gap-1.5 transition-colors disabled:opacity-50"
                      >
                        {isPrinting ? <RefreshCw size={14} className="animate-spin" /> : <Play size={14} />}
                        {isPrinting ? 'Sending to Spooler...' : 'Send to Printer'}
                      </button>
                    ) : null}

                    {/* Fallback browser print button */}
                    <button
                      onClick={() => triggerBrowserPrint(order.fileUrl)}
                      className="bg-white border border-gray-300 hover:bg-gray-100 text-gray-800 font-semibold text-xs px-3 py-2.5 rounded-lg flex items-center gap-1.5 transition-colors"
                      title="Open native browser print window"
                    >
                      <ExternalLink size={14} /> Browser Fallback
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
}
