import React, { useState, useEffect } from 'react';
import { Routes, Route, Navigate, useParams, Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Settings, 
  History, 
  LogOut, 
  Menu, 
  X, 
  Printer, 
  ShieldAlert,
  Loader2
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { cn } from '@/lib/utils';

// Lazy loaded sub-pages for the Dashboard
const LiveOrders = React.lazy(() => import('./LiveOrders'));
const ShopSettings = React.lazy(() => import('./ShopSettings'));
// const OrderHistory = React.lazy(() => import('./OrderHistory')); // Planned for later

export default function ShopDashboardApp() {
  const { shopId } = useParams<{ shopId: string }>();
  const location = useLocation();
  const { currentUser, role, shopId: authorizedShopId, isLoading, logout } = useAuth();
  
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [shopName, setShopName] = useState<string>("Loading Shop...");
  const [isVerifying, setIsVerifying] = useState(true);

  // Close mobile menu automatically when route changes
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  // Fetch shop name for the header
  useEffect(() => {
    async function fetchShopName() {
      if (!shopId) return;
      try {
        const snap = await getDoc(doc(db, 'shops', shopId));
        if (snap.exists()) {
          setShopName(snap.data().name);
        } else {
          setShopName("Unknown Shop");
        }
      } catch (err) {
        console.error("Failed to fetch shop details", err);
      } finally {
        setIsVerifying(false);
      }
    }
    fetchShopName();
  }, [shopId]);

  // ----------------------------------------------------------------------
  // STRICT AUTHORIZATION CHECKS (TENANT ISOLATION)
  // ----------------------------------------------------------------------
  if (isLoading || isVerifying) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-surface-muted">
        <Loader2 className="w-10 h-10 text-brand-600 animate-spin" />
      </div>
    );
  }

  // 1. Not logged in at all -> Send to Login page
  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }

  // 2. Customers shouldn't be here -> Send back to their Kiosk
  if (role === 'CUSTOMER') {
    return <Navigate to={`/s/${shopId}`} replace />;
  }

  // 3. Prevent Shop A owner from accessing Shop B dashboard
  const isAuthorizedForThisShop = role === 'SUPER_ADMIN' || authorizedShopId === shopId;
  
  if (!isAuthorizedForThisShop) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-red-100 max-w-md w-full text-center">
          <ShieldAlert className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-900 mb-2">Access Denied</h2>
          <p className="text-gray-600 mb-6">
            You do not have permission to access the dashboard for this shop.
          </p>
          <button 
            onClick={logout}
            className="bg-gray-900 text-white font-medium py-2 px-6 rounded-lg hover:bg-gray-800 transition-colors"
          >
            Sign Out
          </button>
        </div>
      </div>
    );
  }

  // ----------------------------------------------------------------------
  // DASHBOARD LAYOUT (Sidebar + Main Content)
  // ----------------------------------------------------------------------
  const navLinks = [
    { name: 'Live Orders', path: `/s/${shopId}/dashboard`, icon: LayoutDashboard },
    // { name: 'Order History', path: `/s/${shopId}/dashboard/history`, icon: History },
    { name: 'Shop Settings', path: `/s/${shopId}/dashboard/settings`, icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-surface-muted flex">
      
      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-gray-900/50 z-40 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar Navigation */}
      <aside className={cn(
        "fixed lg:sticky top-0 left-0 z-50 h-screen w-72 bg-white border-r border-gray-200 transform transition-transform duration-300 ease-in-out flex flex-col",
        isMobileMenuOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        <div className="h-16 flex items-center justify-between px-6 border-b border-gray-100">
          <div className="flex items-center gap-2 text-brand-700 font-black text-xl tracking-tight">
            <Printer size={24} />
            <span>AURA <span className="text-gray-900">Pro</span></span>
          </div>
          <button className="lg:hidden text-gray-500 hover:text-gray-900" onClick={() => setIsMobileMenuOpen(false)}>
            <X size={24} />
          </button>
        </div>

        <div className="p-6">
          <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Current Shop</div>
          <div className="font-semibold text-gray-900 truncate mb-6">{shopName}</div>

          <nav className="space-y-1.5">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = location.pathname === link.path;
              return (
                <Link
                  key={link.name}
                  to={link.path}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors duration-200",
                    isActive 
                      ? "bg-brand-50 text-brand-700" 
                      : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                  )}
                >
                  <Icon size={18} className={isActive ? "text-brand-600" : "text-gray-400"} />
                  {link.name}
                </Link>
              );
            })}
          </nav>
        </div>

        <div className="mt-auto p-6 border-t border-gray-100">
          <div className="flex items-center gap-3 mb-4 px-2">
            <div className="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center text-brand-700 font-bold">
              {currentUser.email?.charAt(0).toUpperCase() || 'S'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-gray-900 truncate">{currentUser.email}</p>
              <p className="text-xs text-gray-500 capitalize">{role?.replace('_', ' ').toLowerCase()}</p>
            </div>
          </div>
          <button 
            onClick={logout}
            className="flex items-center gap-2 w-full px-3 py-2 text-sm font-medium text-red-600 hover:bg-red-50 rounded-xl transition-colors"
          >
            <LogOut size={18} /> Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        {/* Mobile Header */}
        <header className="lg:hidden h-16 bg-white border-b border-gray-200 flex items-center justify-between px-4 shrink-0">
          <div className="flex items-center gap-2 font-bold text-gray-900">
            <Printer size={20} className="text-brand-600" />
            {shopName}
          </div>
          <button 
            onClick={() => setIsMobileMenuOpen(true)}
            className="p-2 -mr-2 text-gray-600 hover:bg-gray-100 rounded-lg"
          >
            <Menu size={24} />
          </button>
        </header>

        {/* Scrollable Page Content */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8">
          <React.Suspense fallback={
            <div className="flex justify-center p-12">
              <Loader2 className="w-8 h-8 text-brand-600 animate-spin" />
            </div>
          }>
            <Routes>
              {/* Index route for dashboard shows Live Orders */}
              <Route index element={<LiveOrders />} />
              <Route path="settings" element={<ShopSettings />} />
              {/* <Route path="history" element={<OrderHistory />} /> */}
              
              <Route path="*" element={<Navigate to="" replace />} />
            </Routes>
          </React.Suspense>
        </div>
      </main>

    </div>
  );
}
