import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { 
  Save, 
  QrCode, 
  IndianRupee, 
  Sliders, 
  ShieldCheck, 
  Loader2, 
  AlertCircle 
} from 'lucide-react';
import { toast } from 'sonner';

import { db } from '@/lib/firebase/config';
import { ShopDetails } from '@/pages/kiosk/KioskApp';

export default function ShopSettings() {
  const { shopId } = useParams<{ shopId: string }>();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Form State
  const [name, setName] = useState('');
  const [upiId, setUpiId] = useState('');
  const [allowColor, setAllowColor] = useState(true);
  const [allowDuplex, setAllowDuplex] = useState(true);
  const [maxFileSizeMb, setMaxFileSizeMb] = useState(100);

  // Rate States (in INR)
  const [bwSingle, setBwSingle] = useState<number>(2);
  const [bwDuplex, setBwDuplex] = useState<number>(3);
  const [colorSingle, setColorSingle] = useState<number>(10);
  const [colorDuplex, setColorDuplex] = useState<number>(16);

  useEffect(() => {
    async function loadShopData() {
      if (!shopId) return;
      try {
        const snap = await getDoc(doc(db, 'shops', shopId));
        if (snap.exists()) {
          const data = snap.data() as ShopDetails;
          setName(data.name || '');
          setUpiId(data.upiId || '');
          
          if (data.settings) {
            setAllowColor(data.settings.allowColor ?? true);
            setAllowDuplex(data.settings.allowDuplex ?? true);
            setMaxFileSizeMb(data.settings.maxFileSizeMb ?? 100);
          }

          if (data.rates) {
            setBwSingle(data.rates.bwSingle ?? 2);
            setBwDuplex(data.rates.bwDuplex ?? 3);
            setColorSingle(data.rates.colorSingle ?? 10);
            setColorDuplex(data.rates.colorDuplex ?? 16);
          }
        }
      } catch (err) {
        console.error("Failed to fetch shop settings:", err);
        toast.error("Failed to load settings. Please refresh.");
      } finally {
        setLoading(false);
      }
    }

    loadShopData();
  }, [shopId]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!shopId) return;

    // Strict Validations
    const cleanUpi = upiId.trim();
    if (!cleanUpi.includes('@') || cleanUpi.length < 5) {
      toast.error("Please enter a valid UPI ID (e.g. yourname@okaxis, shop@ybl)");
      return;
    }

    if (bwSingle <= 0 || bwDuplex <= 0 || colorSingle <= 0 || colorDuplex <= 0) {
      toast.error("Rates must be greater than 0.");
      return;
    }

    if (maxFileSizeMb < 1 || maxFileSizeMb > 100) {
      toast.error("Max file size must be between 1 MB and 100 MB.");
      return;
    }

    setSaving(true);
    try {
      const shopRef = doc(db, 'shops', shopId);
      await updateDoc(shopRef, {
        name: name.trim(),
        upiId: cleanUpi,
        rates: {
          bwSingle: Number(bwSingle),
          bwDuplex: Number(bwDuplex),
          colorSingle: Number(colorSingle),
          colorDuplex: Number(colorDuplex),
        },
        settings: {
          allowColor,
          allowDuplex,
          maxFileSizeMb: Number(maxFileSizeMb),
        }
      });
      toast.success("Shop settings and pricing updated successfully!");
    } catch (err) {
      console.error("Save error:", err);
      toast.error("Failed to save changes. Permission denied or network issue.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <Loader2 className="w-8 h-8 text-brand-600 animate-spin mb-2" />
        <p className="text-gray-500 font-medium">Loading settings...</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto pb-12 animate-in fade-in duration-500">
      
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Shop Settings & Pricing</h1>
        <p className="text-gray-500">Configure your store branding, UPI settlement ID, and per-page rates.</p>
      </div>

      <form onSubmit={handleSave} className="space-y-8">
        
        {/* SECTION 1: SHOP IDENTITY & UPI */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
          <div className="flex items-center gap-2 mb-4 pb-3 border-b border-gray-100">
            <QrCode className="text-brand-600 w-5 h-5" />
            <h2 className="text-lg font-bold text-gray-900">Shop Details & UPI Settlement</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Shop Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Ansari Cyber Cafe"
                className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none text-gray-900"
              />
              <p className="text-xs text-gray-400 mt-1">This name appears at the top of your Customer Kiosk.</p>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Merchant UPI ID <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                placeholder="e.g. 9876543210@paytm"
                className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none text-gray-900 font-mono"
              />
              <p className="text-xs text-gray-400 mt-1">
                Kiosk QR codes will route 100% of customer payments directly to this UPI ID.
              </p>
            </div>
          </div>
        </div>

        {/* SECTION 2: PRINT RATES (MATHEMATICAL ENGINE CONFIG) */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
          <div className="flex items-center gap-2 mb-4 pb-3 border-b border-gray-100">
            <IndianRupee className="text-brand-600 w-5 h-5" />
            <h2 className="text-lg font-bold text-gray-900">Per-Page Print Rates (₹)</h2>
          </div>

          <p className="text-sm text-gray-500 mb-6">
            Set the rates charged to customers. Duplex rates apply per physical sheet (double-sided).
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Black & White Rates */}
            <div className="bg-gray-50 p-5 rounded-xl border border-gray-200 space-y-4">
              <h3 className="font-bold text-gray-800 text-sm uppercase tracking-wider">Black & White</h3>
              
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">
                  Single-sided (₹ per page)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-bold">₹</span>
                  <input
                    type="number"
                    min="0.5"
                    step="0.5"
                    required
                    value={bwSingle}
                    onChange={(e) => setBwSingle(parseFloat(e.target.value) || 0)}
                    className="w-full pl-8 pr-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-900 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">
                  Double-sided / Duplex (₹ per sheet)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-bold">₹</span>
                  <input
                    type="number"
                    min="0.5"
                    step="0.5"
                    required
                    value={bwDuplex}
                    onChange={(e) => setBwDuplex(parseFloat(e.target.value) || 0)}
                    className="w-full pl-8 pr-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-900 font-bold"
                  />
                </div>
              </div>
            </div>

            {/* Color Rates */}
            <div className="bg-gray-50 p-5 rounded-xl border border-gray-200 space-y-4">
              <h3 className="font-bold text-gray-800 text-sm uppercase tracking-wider">Color Print</h3>
              
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">
                  Single-sided (₹ per page)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-bold">₹</span>
                  <input
                    type="number"
                    min="1"
                    step="1"
                    required
                    value={colorSingle}
                    onChange={(e) => setColorSingle(parseFloat(e.target.value) || 0)}
                    className="w-full pl-8 pr-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-900 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">
                  Double-sided / Duplex (₹ per sheet)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-bold">₹</span>
                  <input
                    type="number"
                    min="1"
                    step="1"
                    required
                    value={colorDuplex}
                    onChange={(e) => setColorDuplex(parseFloat(e.target.value) || 0)}
                    className="w-full pl-8 pr-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-900 font-bold"
                  />
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* SECTION 3: HARDWARE CAPABILITIES & TOGGLES */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
          <div className="flex items-center gap-2 mb-4 pb-3 border-b border-gray-100">
            <Sliders className="text-brand-600 w-5 h-5" />
            <h2 className="text-lg font-bold text-gray-900">Printer Toggles & Limits</h2>
          </div>

          <div className="space-y-4">
            <label className="flex items-center justify-between p-3.5 bg-gray-50 rounded-xl cursor-pointer hover:bg-gray-100/80 transition-colors">
              <div>
                <p className="font-semibold text-gray-900 text-sm">Allow Color Printing</p>
                <p className="text-xs text-gray-500">Enable if you have an operational color printer.</p>
              </div>
              <input
                type="checkbox"
                checked={allowColor}
                onChange={(e) => setAllowColor(e.target.checked)}
                className="w-5 h-5 text-brand-600 rounded focus:ring-brand-500 border-gray-300"
              />
            </label>

            <label className="flex items-center justify-between p-3.5 bg-gray-50 rounded-xl cursor-pointer hover:bg-gray-100/80 transition-colors">
              <div>
                <p className="font-semibold text-gray-900 text-sm">Allow Duplex (Double-sided) Printing</p>
                <p className="text-xs text-gray-500">Enable if your printer supports auto/manual duplexing.</p>
              </div>
              <input
                type="checkbox"
                checked={allowDuplex}
                onChange={(e) => setAllowDuplex(e.target.checked)}
                className="w-5 h-5 text-brand-600 rounded focus:ring-brand-500 border-gray-300"
              />
            </label>

            <div className="p-3.5 bg-gray-50 rounded-xl flex items-center justify-between">
              <div>
                <p className="font-semibold text-gray-900 text-sm">Maximum Upload Size</p>
                <p className="text-xs text-gray-500">Max size customers can upload per document.</p>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="5"
                  max="100"
                  value={maxFileSizeMb}
                  onChange={(e) => setMaxFileSizeMb(parseInt(e.target.value) || 100)}
                  className="w-20 px-3 py-1.5 bg-white border border-gray-300 rounded-lg text-center font-bold text-gray-900"
                />
                <span className="text-sm font-semibold text-gray-600">MB</span>
              </div>
            </div>
          </div>
        </div>

        {/* SUBMIT BUTTON */}
        <div className="flex items-center justify-end gap-4 pt-4">
          <button
            type="submit"
            disabled={saving}
            className="bg-brand-600 hover:bg-brand-700 disabled:bg-gray-400 text-white font-bold py-3 px-8 rounded-xl flex items-center gap-2 shadow-sm transition-all"
          >
            {saving ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" /> Saving Changes...
              </>
            ) : (
              <>
                <Save className="w-5 h-5" /> Save All Settings
              </>
            )}
          </button>
        </div>

      </form>
    </div>
  );
}
