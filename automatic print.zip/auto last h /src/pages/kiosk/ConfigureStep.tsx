import React, { useState, useEffect, useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Settings, Copy, FileText, ChevronRight, AlertCircle } from 'lucide-react';
import { ShopDetails } from './KioskApp';
import PdfPreviewer from '@/components/kiosk/PdfPreviewer';
import { calculatePrintPrice, PrintJobConfig, PricingResult } from '@/lib/pricing/pricingEngine';
import { formatINR } from '@/lib/utils';
import { toast } from 'sonner';

interface ConfigureStepProps {
  shop: ShopDetails;
}

// Helper to parse page range strings (e.g., "1-3, 5") into a count of unique pages.
// Returns null if the format is invalid or out of bounds.
function getSelectedPagesCount(rangeStr: string, totalPages: number): number | null {
  const trimmed = rangeStr.trim().toLowerCase();
  if (!trimmed || trimmed === 'all') return totalPages;

  const pageSet = new Set<number>();
  const parts = trimmed.split(',');

  for (const part of parts) {
    const p = part.trim();
    if (!p) continue;

    if (p.includes('-')) {
      const [startStr, endStr] = p.split('-');
      const start = parseInt(startStr, 10);
      const end = parseInt(endStr, 10);

      if (isNaN(start) || isNaN(end) || start > end || start < 1 || end > totalPages) {
        return null; // Invalid range
      }
      for (let i = start; i <= end; i++) pageSet.add(i);
    } else {
      const num = parseInt(p, 10);
      if (isNaN(num) || num < 1 || num > totalPages) {
        return null; // Invalid single page
      }
      pageSet.add(num);
    }
  }

  return pageSet.size > 0 ? pageSet.size : null;
}

export default function ConfigureStep({ shop }: ConfigureStepProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const file = location.state?.file as File | undefined;

  // Configuration State
  const [totalPages, setTotalPages] = useState<number>(0);
  const [copies, setCopies] = useState<number>(1);
  const [isColor, setIsColor] = useState<boolean>(false);
  const [isDuplex, setIsDuplex] = useState<boolean>(true); // Default to double-sided to save paper
  const [pageRange, setPageRange] = useState<string>('all');
  
  // Computed pricing state
  const [pricing, setPricing] = useState<PricingResult | null>(null);
  const [pageCountError, setPageCountError] = useState<string | null>(null);

  // If no file in memory, send user back to step 1
  useEffect(() => {
    if (!file) {
      navigate('..', { replace: true }); // Go back to root of kiosk
    } else if (file.type.startsWith('image/')) {
      // Images always have exactly 1 page
      setTotalPages(1);
    }
  }, [file, navigate]);

  // Live Pricing Calculation
  useEffect(() => {
    if (totalPages === 0) return; // Wait for PDF to load

    const selectedPagesCount = getSelectedPagesCount(pageRange, totalPages);
    
    if (selectedPagesCount === null) {
      setPageCountError(`Invalid range. Max pages: ${totalPages}`);
      setPricing(null);
      return;
    }
    setPageCountError(null);

    const config: PrintJobConfig = {
      selectedPages: selectedPagesCount,
      copies: copies,
      isColor: isColor,
      isDuplex: isDuplex
    };

    // Use our secure pricing engine with the shop's rates
    const result = calculatePrintPrice(config, shop.rates);
    
    if (result.error) {
      setPageCountError(result.error);
      setPricing(null);
    } else {
      setPricing(result);
    }
  }, [totalPages, copies, isColor, isDuplex, pageRange, shop.rates]);

  const handleContinue = () => {
    if (pageCountError || !pricing || !file) {
      toast.error("Please fix the errors before continuing.");
      return;
    }

    // Pass the file, config, and calculated pricing to the Payment step
    navigate('../pay', {
      state: {
        file,
        config: {
          copies,
          isColor,
          isDuplex,
          pageRange,
          selectedPagesCount: getSelectedPagesCount(pageRange, totalPages)
        },
        pricing
      }
    });
  };

  if (!file) return null; // Redirecting...

  return (
    <div className="flex flex-col md:flex-row gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Left Column - Preview */}
      <div className="w-full md:w-1/2 flex flex-col gap-4">
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-200">
          <h2 className="text-lg font-bold text-brand-900 mb-3 flex items-center gap-2">
            <FileText size={20} className="text-brand-500" />
            Document Preview
          </h2>
          {file.type === 'application/pdf' ? (
            <PdfPreviewer file={file} onLoadSuccess={setTotalPages} />
          ) : (
            <div className="w-full flex justify-center bg-gray-100 rounded-xl overflow-hidden min-h-[300px]">
              <img 
                src={URL.createObjectURL(file)} 
                alt="Upload preview" 
                className="object-contain max-h-[60vh]"
              />
            </div>
          )}
          
          <div className="mt-3 text-sm text-gray-500 font-medium">
            File: {file.name.length > 30 ? file.name.substring(0, 30) + '...' : file.name}
          </div>
        </div>
      </div>

      {/* Right Column - Print Settings */}
      <div className="w-full md:w-1/2 flex flex-col gap-4">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
          <h2 className="text-lg font-bold text-brand-900 mb-5 flex items-center gap-2">
            <Settings size={20} className="text-brand-500" />
            Print Settings
          </h2>

          <div className="space-y-6">
            
            {/* Color vs B&W (Disabled if shop doesn't allow color) */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Print Type</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setIsColor(false)}
                  className={`py-3 px-4 rounded-xl border-2 font-medium transition-all ${
                    !isColor ? 'border-brand-600 bg-brand-50 text-brand-800' : 'border-gray-200 text-gray-600 hover:border-gray-300'
                  }`}
                >
                  Black & White
                </button>
                <button
                  onClick={() => shop.settings.allowColor && setIsColor(true)}
                  disabled={!shop.settings.allowColor}
                  className={`py-3 px-4 rounded-xl border-2 font-medium transition-all ${
                    isColor ? 'border-brand-600 bg-brand-50 text-brand-800' : 'border-gray-200 text-gray-600 hover:border-gray-300'
                  } disabled:opacity-50 disabled:cursor-not-allowed`}
                >
                  Color
                </button>
              </div>
              {!shop.settings.allowColor && (
                 <p className="text-xs text-orange-600 mt-1 flex items-center gap-1">
                   <AlertCircle size={12} /> This shop currently only prints in Black & White.
                 </p>
              )}
            </div>

            {/* Single vs Duplex (Disabled if shop doesn't allow duplex) */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Sides</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setIsDuplex(false)}
                  className={`py-3 px-4 rounded-xl border-2 font-medium transition-all ${
                    !isDuplex ? 'border-brand-600 bg-brand-50 text-brand-800' : 'border-gray-200 text-gray-600 hover:border-gray-300'
                  }`}
                >
                  Single-sided
                </button>
                <button
                  onClick={() => shop.settings.allowDuplex && setIsDuplex(true)}
                  disabled={!shop.settings.allowDuplex}
                  className={`py-3 px-4 rounded-xl border-2 font-medium transition-all ${
                    isDuplex ? 'border-brand-600 bg-brand-50 text-brand-800' : 'border-gray-200 text-gray-600 hover:border-gray-300'
                  } disabled:opacity-50 disabled:cursor-not-allowed`}
                >
                  Double-sided
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {/* Copies */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-1">
                  <Copy size={16} /> Copies
                </label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={copies}
                  onChange={(e) => setCopies(parseInt(e.target.value) || 1)}
                  className="w-full bg-gray-50 border border-gray-300 text-gray-900 text-lg rounded-xl focus:ring-brand-500 focus:border-brand-500 block p-3"
                />
              </div>

              {/* Page Range */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Pages (e.g. 1-3, 5)
                </label>
                <input
                  type="text"
                  value={pageRange}
                  onChange={(e) => setPageRange(e.target.value)}
                  placeholder="all"
                  className={`w-full bg-gray-50 border text-lg rounded-xl focus:ring-brand-500 block p-3 ${
                    pageCountError ? 'border-red-500 focus:border-red-500 text-red-600' : 'border-gray-300 text-gray-900 focus:border-brand-500'
                  }`}
                />
              </div>
            </div>
            {pageCountError && (
              <p className="text-red-500 text-sm font-medium flex items-center gap-1 mt-1">
                <AlertCircle size={14} /> {pageCountError}
              </p>
            )}

          </div>
        </div>

        {/* Sticky Bottom Pricing & Checkout Bar */}
        <div className="bg-brand-950 p-5 rounded-2xl shadow-xl border border-brand-900 text-white mt-auto sticky bottom-4 z-20">
          <div className="flex justify-between items-end mb-4">
            <div>
              <p className="text-brand-200 text-sm font-medium mb-1">Total Amount</p>
              <h3 className="text-3xl font-bold font-sans">
                {pricing ? formatINR(pricing.totalAmount) : '₹0.00'}
              </h3>
            </div>
            <div className="text-right">
              <p className="text-brand-200 text-sm font-medium mb-1">Paper Used</p>
              <p className="text-lg font-semibold">{pricing?.sheetsUsed || 0} sheets</p>
            </div>
          </div>
          
          <button
            onClick={handleContinue}
            disabled={!pricing || !!pageCountError || totalPages === 0}
            className="w-full bg-brand-400 hover:bg-brand-300 disabled:bg-gray-700 disabled:text-gray-400 text-brand-950 font-bold text-lg py-4 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg"
          >
            Confirm & Pay <ChevronRight size={20} />
          </button>
        </div>
      </div>

    </div>
  );
}
