import React, { useEffect, useState } from 'react';
import { Routes, Route, useParams, Navigate, useNavigate } from 'react-router-dom';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { useAuth } from '@/contexts/AuthContext';
import { Printer, AlertTriangle } from 'lucide-react';

// Lazy load steps for performance
const UploadStep = React.lazy(() => import('./UploadStep'));
const ConfigureStep = React.lazy(() => import('./ConfigureStep'));
const PaymentStep = React.lazy(() => import('./PaymentStep'));
const OrderStatusStep = React.lazy(() => import('./OrderStatusStep'));

// Interface for Shop Data
export interface ShopDetails {
  id: string;
  name: string;
  upiId: string;
  isLocked: boolean; // Managed by Super Admin
  settings: {
    allowColor: boolean;
    allowDuplex: boolean;
    maxFileSizeMb: number;
  };
  rates: {
    bwSingle: number;
    bwDuplex: number;
    colorSingle: number;
    colorDuplex: number;
  };
}

export default function KioskApp() {
  const { shopId } = useParams<{ shopId: string }>();
  const [shop, setShop] = useState<ShopDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { authenticateAsCustomer } = useAuth();
  
  // We need to fetch the shop details immediately to ensure the link is valid.
  useEffect(() => {
    async function initKiosk() {
      if (!shopId) {
        setError("Invalid Shop URL.");
        setLoading(false);
        return;
      }

      try {
        // 1. Authenticate user anonymously to allow secure uploads later
        await authenticateAsCustomer();

        // 2. Fetch Shop Details from Firestore
        const shopRef = doc(db, 'shops', shopId);
        const shopSnap = await getDoc(shopRef);

        if (!shopSnap.exists()) {
          setError("This shop does not exist or has been removed.");
        } else {
          const shopData = shopSnap.data() as ShopDetails;
          
          // 3. Multi-tenant SaaS Check: Is the shop locked by Sabir?
          if (shopData.isLocked) {
             setError("This printing service is currently disabled. Please contact the shop owner.");
          } else {
            setShop({ id: shopSnap.id, ...shopData });
          }
        }
      } catch (err) {
        console.error("Error loading kiosk:", err);
        setError("Network error. Please check your internet connection.");
      } finally {
        setLoading(false);
      }
    }

    initKiosk();
  }, [shopId, authenticateAsCustomer]);

  // Loading State
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-surface-muted px-4">
        <div className="flex flex-col items-center gap-3">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-brand-600"></div>
          <p className="text-brand-900 font-medium">Connecting to Kiosk...</p>
        </div>
      </div>
    );
  }

  // Error State (Invalid URL, Locked Shop, Network Issue)
  if (error || !shop) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-surface-muted px-4">
        <div className="bg-white p-8 rounded-2xl shadow-soft max-w-md w-full text-center border border-red-100">
          <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-900 mb-2">Service Unavailable</h2>
          <p className="text-gray-600 mb-6">{error}</p>
        </div>
      </div>
    );
  }

  // Active Kiosk Layout
  return (
    <div className="min-h-screen bg-surface-muted flex flex-col">
      {/* Top Header - Branded to the specific shop */}
      <header className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-brand-50 p-2 rounded-lg text-brand-600">
              <Printer size={20} />
            </div>
            <div>
              <h1 className="font-bold text-brand-950 leading-tight">{shop.name}</h1>
              <p className="text-xs text-gray-500 font-medium">Powered by AURA Print Pro</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Area - Multi-step Router */}
      <main className="flex-1 max-w-3xl mx-auto w-full p-4 md:p-6 pb-24">
        <React.Suspense fallback={
          <div className="flex justify-center p-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-600"></div>
          </div>
        }>
          <Routes>
            {/* Step 1: Upload File */}
            <Route path="/" element={<UploadStep shop={shop} />} />
            
            {/* Step 2: PDF Preview & Print Settings (B&W/Color, Copies) */}
            <Route path="/configure" element={<ConfigureStep shop={shop} />} />
            
            {/* Step 3: Checkout & UPI Payment */}
            <Route path="/pay" element={<PaymentStep shop={shop} />} />
            
            {/* Step 4: Live Order Tracking (Waiting for print) */}
            <Route path="/status/:orderId" element={<OrderStatusStep />} />
            
            <Route path="*" element={<Navigate to={`/s/${shopId}`} replace />} />
          </Routes>
        </React.Suspense>
      </main>
    </div>
  );
}
