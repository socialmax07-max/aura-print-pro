import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, onSnapshot } from 'firebase/firestore';
import { CheckCircle2, Clock, Printer, XCircle, AlertTriangle, FileText, Loader2, ArrowLeft } from 'lucide-react';

import { db } from '@/lib/firebase/config';
import { OrderSnapshot } from '@/lib/validations/zodSchemas';
import { formatINR } from '@/lib/utils';

export default function OrderStatusStep() {
  const { shopId, orderId } = useParams<{ shopId: string; orderId: string }>();
  const navigate = useNavigate();
  
  const [order, setOrder] = useState<OrderSnapshot | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!shopId || !orderId) {
      setError("Invalid Order URL.");
      setLoading(false);
      return;
    }

    // Attach real-time listener to the specific order document
    const orderRef = doc(db, 'shops', shopId, 'orders', orderId);
    
    const unsubscribe = onSnapshot(
      orderRef,
      (docSnap) => {
        if (docSnap.exists()) {
          setOrder({ id: docSnap.id, ...docSnap.data() } as OrderSnapshot);
          setError(null);
        } else {
          setError("Order not found. It may have been deleted.");
        }
        setLoading(false);
      },
      (err) => {
        console.error("Error listening to order:", err);
        setError("Lost connection to the live tracker.");
        setLoading(false);
      }
    );

    // Cleanup listener on unmount to save memory and Firebase reads
    return () => unsubscribe();
  }, [shopId, orderId]);

  // UI rendering based on the strict state machine statuses defined in zodSchemas
  const renderStatusContent = () => {
    if (!order) return null;

    switch (order.status) {
      case 'PENDING_PAYMENT':
        return {
          icon: <AlertTriangle className="w-16 h-16 text-orange-500 mb-4" />,
          title: "Payment Pending",
          desc: "We are waiting for you to complete the payment.",
          bg: "bg-orange-50 border-orange-100",
          textColor: "text-orange-900"
        };
      
      case 'PAYMENT_VERIFYING':
        return {
          icon: <Clock className="w-16 h-16 text-blue-500 mb-4 animate-pulse" />,
          title: "Verifying Payment",
          desc: "Please wait. The shopkeeper is confirming your payment.",
          bg: "bg-blue-50 border-blue-100",
          textColor: "text-blue-900"
        };

      case 'AUTHORIZED':
      case 'QUEUED':
        return {
          icon: <Printer className="w-16 h-16 text-purple-500 mb-4 animate-bounce" />,
          title: "In Print Queue",
          desc: "Payment verified! Your document is queued for printing.",
          bg: "bg-purple-50 border-purple-100",
          textColor: "text-purple-900"
        };

      case 'PRINTING':
        return {
          icon: <Printer className="w-16 h-16 text-brand-600 mb-4" />,
          title: "Printing Now...",
          desc: "Your document is currently being printed.",
          bg: "bg-brand-50 border-brand-100",
          textColor: "text-brand-900"
        };

      case 'PRINTED':
        return {
          icon: <CheckCircle2 className="w-16 h-16 text-green-500 mb-4" />,
          title: "Printed Successfully!",
          desc: "Please collect your document from the counter.",
          bg: "bg-green-50 border-green-100",
          textColor: "text-green-900"
        };

      case 'REJECTED':
        return {
          icon: <XCircle className="w-16 h-16 text-red-500 mb-4" />,
          title: "Order Rejected",
          desc: "The shopkeeper rejected this order. (e.g. Payment not received or invalid file)",
          bg: "bg-red-50 border-red-100",
          textColor: "text-red-900"
        };

      case 'PRINT_FAILED':
        return {
          icon: <AlertTriangle className="w-16 h-16 text-red-500 mb-4" />,
          title: "Printer Error",
          desc: "Something went wrong at the printer. Please talk to the shopkeeper.",
          bg: "bg-red-50 border-red-100",
          textColor: "text-red-900"
        };
      
      case 'CANCELLED':
        return {
          icon: <XCircle className="w-16 h-16 text-gray-500 mb-4" />,
          title: "Order Cancelled",
          desc: "This print job was cancelled.",
          bg: "bg-gray-50 border-gray-200",
          textColor: "text-gray-900"
        };

      default:
        return {
          icon: <Loader2 className="w-16 h-16 text-gray-400 mb-4 animate-spin" />,
          title: "Processing",
          desc: "Loading status...",
          bg: "bg-gray-50 border-gray-100",
          textColor: "text-gray-900"
        };
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px]">
        <Loader2 className="w-10 h-10 text-brand-600 animate-spin mb-4" />
        <p className="text-gray-600 font-medium">Connecting to live tracker...</p>
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] bg-white rounded-2xl shadow-sm border border-red-100 p-8">
        <AlertTriangle className="w-16 h-16 text-red-500 mb-4" />
        <h2 className="text-xl font-bold text-gray-900 mb-2">Status Unavailable</h2>
        <p className="text-gray-600 mb-6 text-center">{error}</p>
        <button 
          onClick={() => navigate(`/s/${shopId}`)}
          className="bg-brand-500 hover:bg-brand-600 text-white font-semibold py-3 px-6 rounded-xl transition-colors"
        >
          Start New Print
        </button>
      </div>
    );
  }

  const statusUI = renderStatusContent();

  return (
    <div className="max-w-xl mx-auto w-full animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Live Status Card */}
      <div className={`flex flex-col items-center text-center p-8 rounded-t-3xl border-b-0 border-2 transition-colors duration-500 ${statusUI?.bg}`}>
        {statusUI?.icon}
        <h2 className={`text-3xl font-black mb-2 ${statusUI?.textColor}`}>
          {statusUI?.title}
        </h2>
        <p className="text-gray-700 font-medium max-w-sm">
          {statusUI?.desc}
        </p>
      </div>

      {/* Order Details Receipt */}
      <div className="bg-white p-6 rounded-b-3xl border-2 border-t-0 border-gray-200 shadow-sm border-dashed">
        <div className="flex justify-between items-center mb-6 pb-6 border-b border-gray-100 border-dashed">
          <div>
            <p className="text-xs text-gray-500 font-semibold uppercase tracking-wider mb-1">Order Ref</p>
            <p className="text-2xl font-bold text-gray-900 tracking-wider">{(order as any).shortRef || order.id.substring(0, 6)}</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-500 font-semibold uppercase tracking-wider mb-1">Paid via</p>
            <p className="text-lg font-bold text-gray-900">{order.paymentMethod}</p>
          </div>
        </div>

        <div className="space-y-3 mb-8">
          <div className="flex items-start gap-3">
            <FileText className="w-5 h-5 text-gray-400 shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">{order.fileName}</p>
              <p className="text-xs text-gray-500 mt-1">
                {order.config.isColor ? 'Color' : 'B&W'} • {order.config.isDuplex ? 'Double-sided' : 'Single-sided'} • {order.config.copies} Copies
              </p>
            </div>
          </div>
        </div>

        <div className="flex justify-between items-end bg-gray-50 p-4 rounded-xl">
          <div>
            <p className="text-sm text-gray-500 font-medium">Total Amount</p>
            <p className="text-xs text-gray-400 mt-0.5">Includes all taxes</p>
          </div>
          <p className="text-2xl font-black text-brand-900">{formatINR(order.amount)}</p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mt-8 flex flex-col items-center gap-4">
        {(order.status === 'PRINTED' || order.status === 'REJECTED' || order.status === 'PRINT_FAILED' || order.status === 'CANCELLED') && (
          <button
            onClick={() => navigate(`/s/${shopId}`)}
            className="flex items-center gap-2 text-brand-700 font-semibold bg-brand-50 hover:bg-brand-100 py-3 px-6 rounded-xl transition-colors"
          >
            <ArrowLeft size={18} /> Print Another Document
          </button>
        )}
        
        <p className="text-xs text-gray-400 text-center">
          Secure Order ID: {order.id}<br/>
          Protected by AURA Print Pro
        </p>
      </div>

    </div>
  );
}
