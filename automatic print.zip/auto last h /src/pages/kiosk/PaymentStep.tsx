import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { ShieldCheck, IndianRupee, Loader2, QrCode, AlertCircle, HandCoins } from 'lucide-react';
import { toast } from 'sonner';

import { db, storage } from '@/lib/firebase/config';
import { useAuth } from '@/contexts/AuthContext';
import { ShopDetails } from './KioskApp';
import { PrintJobConfig, PricingResult } from '@/lib/pricing/pricingEngine';
import { formatINR, generateShortOrderId } from '@/lib/utils';
import { OrderStatus } from '@/lib/validations/zodSchemas';

interface PaymentStepProps {
  shop: ShopDetails;
}

export default function PaymentStep({ shop }: PaymentStepProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  
  const file = location.state?.file as File | undefined;
  const config = location.state?.config as PrintJobConfig | undefined;
  const pricing = location.state?.pricing as PricingResult | undefined;

  // Upload & Order State
  const [isUploading, setIsUploading] = useState(true);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [orderId, setOrderId] = useState<string | null>(null);
  const [shortRef, setShortRef] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmittingPayment, setIsSubmittingPayment] = useState(false);

  // 1. Initial Processing: Upload File & Create Pending Order
  useEffect(() => {
    if (!file || !config || !pricing || !currentUser) {
      navigate('..', { replace: true });
      return;
    }

    // Prevent duplicate uploads on re-renders
    if (orderId || error) return;

    const createOrderAndUpload = async () => {
      try {
        const newOrderId = doc(db, 'shops', shop.id, 'orders', 'new').id; // Generate unique ID
        const generatedRef = generateShortOrderId();
        setShortRef(generatedRef);
        
        // 1. Upload File to Secure Storage path (Tenant Isolated)
        const fileExt = file.name.split('.').pop() || 'pdf';
        const storagePath = `shops/${shop.id}/orders/${newOrderId}/${generatedRef}.${fileExt}`;
        const storageRef = ref(storage, storagePath);
        
        const uploadTask = uploadBytesResumable(storageRef, file, {
          customMetadata: { customerId: currentUser.uid } // Critical for storage.rules
        });

        uploadTask.on('state_changed', 
          (snapshot) => {
            const progress = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
            setUploadProgress(progress);
          },
          (err) => {
            console.error("Upload failed:", err);
            setError("Failed to upload the file safely. Please try again.");
            setIsUploading(false);
          },
          async () => {
            // 2. Upload Complete -> Create Firestore Order
            const downloadUrl = await getDownloadURL(uploadTask.snapshot.ref);
            
            const newOrder = {
              id: newOrderId,
              shortRef: generatedRef,
              shopId: shop.id,
              customerId: currentUser.uid,
              fileName: file.name,
              fileStoragePath: storagePath,
              fileUrl: downloadUrl, // Can be used by admin for direct printing
              config: config,
              amount: pricing.totalAmount,
              sheetsUsed: pricing.sheetsUsed,
              status: 'PENDING_PAYMENT' as OrderStatus,
              paymentMethod: 'UPI', // Default, can switch to CASH
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            };

            await setDoc(doc(db, 'shops', shop.id, 'orders', newOrderId), newOrder);
            
            setOrderId(newOrderId);
            setIsUploading(false);
          }
        );
      } catch (err) {
        console.error("Order creation error:", err);
        setError("Failed to create the order. Please check your connection.");
        setIsUploading(false);
      }
    };

    createOrderAndUpload();
  }, [file, config, pricing, currentUser, navigate, shop.id, orderId, error]);

  // 2. Handle User clicking "I've Paid via UPI"
  const handleUpiPaid = async () => {
    if (!orderId) return;
    setIsSubmittingPayment(true);
    try {
      const orderRef = doc(db, 'shops', shop.id, 'orders', orderId);
      // Strictly advance state. Shopkeeper must now verify.
      await setDoc(orderRef, { 
        status: 'PAYMENT_VERIFYING',
        paymentMethod: 'UPI',
        updatedAt: serverTimestamp() 
      }, { merge: true });
      
      navigate(`../status/${orderId}`, { replace: true });
    } catch (err) {
      toast.error("Failed to notify shopkeeper. Please try again.");
      setIsSubmittingPayment(false);
    }
  };

  // 3. Handle User clicking "Pay by Cash"
  const handleCashPayment = async () => {
    if (!orderId) return;
    setIsSubmittingPayment(true);
    try {
      const orderRef = doc(db, 'shops', shop.id, 'orders', orderId);
      await setDoc(orderRef, { 
        status: 'PAYMENT_VERIFYING',
        paymentMethod: 'CASH',
        updatedAt: serverTimestamp() 
      }, { merge: true });
      
      navigate(`../status/${orderId}`, { replace: true });
    } catch (err) {
      toast.error("Failed to notify shopkeeper. Please try again.");
      setIsSubmittingPayment(false);
    }
  };

  // Generate UPI URI
  // Format: upi://pay?pa=<UPI_ID>&pn=<PAYEE_NAME>&am=<AMOUNT>&tr=<TRANSACTION_REF>&cu=INR
  const upiUri = `upi://pay?pa=${encodeURIComponent(shop.upiId)}&pn=${encodeURIComponent(shop.name)}&am=${pricing?.totalAmount}&tr=${shortRef}&cu=INR`;

  if (isUploading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[500px] bg-white rounded-2xl shadow-sm border border-gray-200 p-8 animate-in fade-in duration-500">
        <Loader2 className="w-16 h-16 text-brand-600 animate-spin mb-6" />
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Preparing your order</h2>
        <p className="text-gray-500 mb-8 text-center max-w-sm">
          Please wait while we securely encrypt and upload your document to the shop's queue.
        </p>
        
        <div className="w-full max-w-md bg-gray-100 rounded-full h-3 mb-2 overflow-hidden">
          <div 
            className="bg-brand-500 h-3 rounded-full transition-all duration-300 ease-out" 
            style={{ width: `${uploadProgress}%` }}
          ></div>
        </div>
        <p className="text-sm font-semibold text-brand-700">{uploadProgress}% Uploaded</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] bg-white rounded-2xl shadow-sm border border-red-100 p-8">
        <AlertCircle className="w-16 h-16 text-red-500 mb-4" />
        <h2 className="text-xl font-bold text-gray-900 mb-2">Something went wrong</h2>
        <p className="text-gray-600 mb-6 text-center">{error}</p>
        <button 
          onClick={() => navigate('..')}
          className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold py-3 px-6 rounded-xl transition-colors"
        >
          Go Back and Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col md:flex-row gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Left Column - Payment Details & Cash Option */}
      <div className="w-full md:w-1/2 flex flex-col gap-4">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-6 pb-6 border-b border-gray-100">
            <div>
              <p className="text-sm text-gray-500 font-medium mb-1">Order Reference</p>
              <p className="text-2xl font-black text-gray-900 tracking-wider">{shortRef}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-500 font-medium mb-1">Amount to Pay</p>
              <p className="text-2xl font-bold text-brand-700">{formatINR(pricing?.totalAmount || 0)}</p>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900 flex items-center gap-2">
              <IndianRupee size={18} className="text-gray-500" />
              Order Summary
            </h3>
            <ul className="text-sm text-gray-600 space-y-2">
              <li className="flex justify-between">
                <span>Document</span>
                <span className="font-medium text-gray-900 truncate max-w-[150px]">{file?.name}</span>
              </li>
              <li className="flex justify-between">
                <span>Pages selected</span>
                <span className="font-medium text-gray-900">{config?.selectedPages}</span>
              </li>
              <li className="flex justify-between">
                <span>Copies</span>
                <span className="font-medium text-gray-900">{config?.copies}</span>
              </li>
              <li className="flex justify-between">
                <span>Type</span>
                <span className="font-medium text-gray-900">
                  {config?.isColor ? 'Color' : 'B&W'} • {config?.isDuplex ? 'Double-sided' : 'Single-sided'}
                </span>
              </li>
            </ul>
          </div>
        </div>

        <button
          onClick={handleCashPayment}
          disabled={isSubmittingPayment}
          className="w-full bg-white border-2 border-gray-200 hover:border-gray-300 text-gray-700 font-bold text-lg py-4 rounded-xl transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          <HandCoins size={20} />
          Pay via Cash at Counter
        </button>
      </div>

      {/* Right Column - Secure QR Checkout */}
      <div className="w-full md:w-1/2">
        <div className="bg-brand-950 p-8 rounded-2xl shadow-xl border border-brand-900 flex flex-col items-center text-center">
          <QrCode className="text-brand-300 w-10 h-10 mb-3" />
          <h2 className="text-xl font-bold text-white mb-2">Scan to Pay via UPI</h2>
          <p className="text-brand-200 text-sm mb-8 px-4">
            Scan this QR with PhonePe, GPay, or Paytm. The exact amount and order reference are already included.
          </p>

          <div className="bg-white p-4 rounded-2xl shadow-inner mb-8">
            <QRCodeSVG 
              value={upiUri} 
              size={220}
              level="M"
              includeMargin={false}
            />
          </div>

          <div className="w-full space-y-3">
            <button
              onClick={handleUpiPaid}
              disabled={isSubmittingPayment}
              className="w-full bg-brand-400 hover:bg-brand-300 disabled:bg-brand-800 disabled:text-gray-400 text-brand-950 font-bold text-lg py-4 rounded-xl transition-all shadow-lg"
            >
              {isSubmittingPayment ? 'Processing...' : "I've Paid via UPI"}
            </button>
            <p className="text-xs text-brand-300/70 flex items-center justify-center gap-1">
              <ShieldCheck size={14} /> Shopkeeper will verify payment automatically
            </p>
          </div>
        </div>
      </div>
      
    </div>
  );
}
