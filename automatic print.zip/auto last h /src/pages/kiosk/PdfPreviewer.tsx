import React, { useState, useMemo } from 'react';
import { Document, Page } from 'react-pdf';
import { ChevronLeft, ChevronRight, FileX, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

// We import these CSS files to prevent console warnings, even though we disable the layers for performance.
import 'react-pdf/dist/esm/Page/AnnotationLayer.css';
import 'react-pdf/dist/esm/Page/TextLayer.css';

interface PdfPreviewerProps {
  file: File;
  onLoadSuccess: (totalPages: number) => void;
  className?: string;
}

export default function PdfPreviewer({ file, onLoadSuccess, className }: PdfPreviewerProps) {
  const [numPages, setNumPages] = useState<number>(0);
  const [pageNumber, setPageNumber] = useState<number>(1);
  const [error, setError] = useState<string | null>(null);

  // useMemo ensures we don't recreate the file URL on every re-render
  const fileUrl = useMemo(() => URL.createObjectURL(file), [file]);

  function onDocumentLoadSuccess({ numPages }: { numPages: number }) {
    setNumPages(numPages);
    setPageNumber(1);
    onLoadSuccess(numPages); // Send genuine page count to parent for pricing calculation
  }

  function onDocumentLoadError(error: Error) {
    console.error("PDF load error:", error);
    setError("Unable to read this PDF. The file might be corrupted or password protected.");
  }

  function goToPrevPage() {
    setPageNumber((prev) => Math.max(prev - 1, 1));
  }

  function goToNextPage() {
    setPageNumber((prev) => Math.min(prev + 1, numPages));
  }

  if (error) {
    return (
      <div className={cn("flex flex-col items-center justify-center p-8 bg-red-50 rounded-xl border border-red-100 text-center", className)}>
        <FileX className="w-12 h-12 text-red-500 mb-3" />
        <p className="text-red-700 font-medium mb-1">Failed to load preview</p>
        <p className="text-sm text-red-600">{error}</p>
      </div>
    );
  }

  return (
    <div className={cn("flex flex-col items-center bg-gray-50 rounded-xl border border-gray-200 overflow-hidden", className)}>
      
      {/* PDF Document Render Area */}
      <div className="relative w-full flex justify-center bg-gray-100 min-h-[400px] max-h-[60vh] overflow-y-auto p-4 custom-scrollbar">
        <Document
          file={fileUrl}
          onLoadSuccess={onDocumentLoadSuccess}
          onLoadError={onDocumentLoadError}
          loading={
            <div className="absolute inset-0 flex flex-col items-center justify-center text-brand-600 h-[400px]">
              <Loader2 className="w-8 h-8 animate-spin mb-2" />
              <p className="text-sm font-medium">Processing PDF...</p>
            </div>
          }
        >
          {numPages > 0 && (
            <div className="shadow-card border border-gray-200 bg-white">
              <Page
                pageNumber={pageNumber}
                width={Math.min(window.innerWidth - 64, 400)} // Responsive width, max 400px
                renderTextLayer={false} // Disabled for mobile performance
                renderAnnotationLayer={false} // Disabled for mobile performance
                className="transition-opacity duration-300"
              />
            </div>
          )}
        </Document>
      </div>

      {/* Pagination Controls */}
      {numPages > 0 && (
        <div className="w-full bg-white border-t border-gray-200 p-3 flex items-center justify-between">
          <button
            onClick={goToPrevPage}
            disabled={pageNumber <= 1}
            type="button"
            className="p-2 rounded-lg text-gray-700 hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            aria-label="Previous page"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          
          <div className="text-sm font-medium text-gray-700 font-sans">
            Page <span className="text-brand-700 font-bold">{pageNumber}</span> of {numPages}
          </div>
          
          <button
            onClick={goToNextPage}
            disabled={pageNumber >= numPages}
            type="button"
            className="p-2 rounded-lg text-gray-700 hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            aria-label="Next page"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
      )}
    </div>
  );
}
