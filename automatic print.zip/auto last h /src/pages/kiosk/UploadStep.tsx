import React, { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDropzone, FileRejection } from 'react-dropzone';
import { UploadCloud, FileText, Image as ImageIcon, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { ShopDetails } from './KioskApp';

interface UploadStepProps {
  shop: ShopDetails;
}

export default function UploadStep({ shop }: UploadStepProps) {
  const navigate = useNavigate();

  // Handle successful file drop
  const onDropAccepted = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      // Memory state ke zariye file ko next step par pass karna
      // Isse Firebase ka upload bill tab tak nahi aayega jab tak order confirm na ho
      navigate('configure', { state: { file } });
    }
  }, [navigate]);

  // Handle errors like >100MB or wrong file type
  const onDropRejected = useCallback((fileRejections: FileRejection[]) => {
    const rejection = fileRejections[0];
    const maxMb = shop.settings?.maxFileSizeMb || 100;

    if (rejection.errors[0]?.code === 'file-too-large') {
      toast.error(`File is too large. Maximum size is ${maxMb}MB.`);
    } else if (rejection.errors[0]?.code === 'file-invalid-type') {
      toast.error("Unsupported file format. Please upload PDF, JPG, or PNG.");
    } else {
      toast.error(rejection.errors[0]?.message || "Failed to accept the file.");
    }
  }, [shop.settings]);

  // React Dropzone configuration
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDropAccepted,
    onDropRejected,
    maxFiles: 1, // Kiosk pe ek baar me ek hi document flow rakhenge
    maxSize: (shop.settings?.maxFileSizeMb || 100) * 1024 * 1024, // MB to Bytes
    accept: {
      'application/pdf': ['.pdf'],
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
    }
  });

  return (
    <div className="flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-brand-950 mb-2">Upload your document</h2>
        <p className="text-gray-600">Select the file you want to print. We currently support PDF, JPG, and PNG formats.</p>
      </div>

      <div 
        {...getRootProps()} 
        className={`
          relative flex flex-col items-center justify-center w-full min-h-[320px] 
          border-2 border-dashed rounded-2xl p-8 cursor-pointer transition-colors duration-200
          ${isDragActive 
            ? 'border-brand-500 bg-brand-50' 
            : 'border-gray-300 bg-white hover:bg-gray-50 hover:border-brand-400'}
        `}
      >
        <input {...getInputProps()} />
        
        <div className={`p-4 rounded-full mb-4 ${isDragActive ? 'bg-brand-200 text-brand-700' : 'bg-brand-100 text-brand-600'}`}>
          <UploadCloud size={40} />
        </div>
        
        <h3 className="text-lg font-semibold text-gray-900 mb-1 text-center">
          {isDragActive ? "Drop the file here" : "Tap to upload or drag & drop"}
        </h3>
        <p className="text-sm text-gray-500 text-center max-w-xs mb-6">
          Maximum file size: {shop.settings?.maxFileSizeMb || 100} MB
        </p>

        {/* Accepted Formats Badges */}
        <div className="flex items-center gap-4 text-sm text-gray-600 font-medium">
          <div className="flex items-center gap-1.5 bg-gray-100 px-3 py-1.5 rounded-md border border-gray-200">
            <FileText size={16} className="text-red-500" /> PDF
          </div>
          <div className="flex items-center gap-1.5 bg-gray-100 px-3 py-1.5 rounded-md border border-gray-200">
            <ImageIcon size={16} className="text-blue-500" /> JPG / PNG
          </div>
        </div>
      </div>

      {/* Trust & Privacy Notice */}
      <div className="mt-6 bg-blue-50 text-blue-800 p-4 rounded-xl flex items-start gap-3 border border-blue-100">
        <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
        <div className="text-sm">
          <p className="font-semibold mb-1">Secure & Private</p>
          <p className="text-blue-700/80">
            Your files are securely processed and automatically deleted from our servers after printing. We strictly respect your privacy.
          </p>
        </div>
      </div>
    </div>
  );
}
