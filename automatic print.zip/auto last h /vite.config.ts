import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  build: {
    // Production ke liye code splitting (Optimization)
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom', 'react-router-dom'],
          firebase: ['firebase/app', 'firebase/auth', 'firebase/firestore', 'firebase/storage'],
          pdf: ['pdfjs-dist', 'react-pdf', 'pdf-lib', '@react-pdf/renderer']
        },
      },
    },
    // Chunks limit badhana kyunki PDF libraries thodi heavy hoti hain
    chunkSizeWarningLimit: 1000,
  },
  // QZ tray ya dusri local networking libraries ke liye dev server configuration
  server: {
    port: 5173,
    strictPort: true,
  },
});
